// sessionapi.ts
import { apiService } from './userapi';

const API_BASE_URL = 'http://localhost:8080/api';

export interface PracticeSession {
  id?: string;
  user_id: string;
  topic_id: string;
  start_time?: Date;
  end_time?: Date;
  status: 'active' | 'completed' | 'cancelled';
  created_at?: Date;
  updated_at?: Date;
  feedback?: Feedback;
}

export interface Feedback {
  id?: string;
  session_id?: string;
  transcript?: string;
  analysis?: string;
  grammar?: number;
  pronunciation?: number;
  fluency?: number;
  timestamp?: Date;
  score?: number;
  corrections?: string[];
  feedback?: string;
}

class SessionApiService {
  async startSession(sessionData: PracticeSession): Promise<PracticeSession> {
    try {
      const response = await fetch(`${API_BASE_URL}/sessions`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${apiService.getCurrentUser()?.token}`
        },
        body: JSON.stringify(sessionData)
      });

      if (!response.ok) {
        throw new Error(`Failed to start session: ${response.statusText}`);
      }

      return await response.json();
    } catch (error) {
      console.error('Error starting session:', error);
      throw error;
    }
  }

  async endSession(sessionId: string, feedbackData: Feedback): Promise<any> {
    try {
      const response = await fetch(`${API_BASE_URL}/sessions/${sessionId}`, {
        method: 'PUT',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${apiService.getCurrentUser()?.token}`
        },
        body: JSON.stringify(feedbackData)
      });

      if (!response.ok) {
        throw new Error(`Failed to end session: ${response.statusText}`);
      }

      return await response.json();
    } catch (error) {
      console.error('Error ending session:', error);
      throw error;
    }
  }

  async getSessionFeedback(sessionId: string): Promise<Feedback> {
    try {
      const response = await fetch(`${API_BASE_URL}/sessions/${sessionId}/feedback`, {
        method: 'GET',
        headers: {
          'Authorization': `Bearer ${apiService.getCurrentUser()?.token}`
        }
      });

      if (!response.ok) {
        throw new Error(`Failed to get session feedback: ${response.statusText}`);
      }

      return await response.json();
    } catch (error) {
      console.error('Error getting session feedback:', error);
      throw error;
    }
  }

  async getUserSessions(): Promise<PracticeSession[]> {
    try {
      const response = await fetch(`${API_BASE_URL}/user/sessions`, {
        method: 'GET',
        headers: {
          'Authorization': `Bearer ${apiService.getCurrentUser()?.token}`
        }
      });

      if (!response.ok) {
        throw new Error(`Failed to get user sessions: ${response.statusText}`);
      }

      return await response.json();
    } catch (error) {
      console.error('Error getting user sessions:', error);
      throw error;
    }
  }

  async getSession(sessionId: string): Promise<PracticeSession> {
    try {
      const response = await fetch(`${API_BASE_URL}/sessions/${sessionId}`, {
        method: 'GET',
        headers: {
          'Authorization': `Bearer ${apiService.getCurrentUser()?.token}`
        }
      });

      if (!response.ok) {
        throw new Error(`Failed to get session details: ${response.statusText}`);
      }

      return await response.json();
    } catch (error) {
      console.error('Error getting session details:', error);
      throw error;
    }
  }
}

export const sessionApiService = new SessionApiService();

// Export individual methods for easier importing
export const {
  startSession,
  endSession,
  getSessionFeedback,
  getUserSessions,
  getSession
} = sessionApiService;