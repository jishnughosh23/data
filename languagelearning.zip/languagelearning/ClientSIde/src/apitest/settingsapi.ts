// settingsapi.ts
import { apiService } from './userapi';

const API_BASE_URL = 'http://localhost:8080/api';

export interface UserSettings {
  id?: string;
  userId?: string;
  primaryLanguage: string;
  learningLanguages: string[];
  notifications: {
    practice: boolean;
    achievements: boolean;
    reminders: boolean;
    marketing: boolean;
  };
  audioSettings: {
    microphone: string;
    speakers: string;
    volume: number;
  };
  videoSettings: {
    camera: string;
    quality: string;
  };
  bio?: string;
}

export interface ProfileUpdate {
  username: string;
  email: string;
  bio: string;
  avatarUrl?: string;
}

class SettingsApiService {
  async getUserSettings(): Promise<UserSettings> {
    try {
      const response = await fetch(`${API_BASE_URL}/settings`, {
        method: 'GET',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${apiService.getCurrentUser()?.token}`
        }
      });

      if (!response.ok) {
        throw new Error(`Failed to get user settings: ${response.statusText}`);
      }

      return await response.json();
    } catch (error) {
      console.error('Error getting user settings:', error);
      throw error;
    }
  }

  async updateUserSettings(settings: UserSettings): Promise<UserSettings> {
    try {
      const response = await fetch(`${API_BASE_URL}/settings`, {
        method: 'PUT',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${apiService.getCurrentUser()?.token}`
        },
        body: JSON.stringify(settings)
      });

      if (!response.ok) {
        throw new Error(`Failed to update user settings: ${response.statusText}`);
      }

      return await response.json();
    } catch (error) {
      console.error('Error updating user settings:', error);
      throw error;
    }
  }

  async updateUserProfile(profileData: ProfileUpdate): Promise<any> {
    try {
      const response = await fetch(`${API_BASE_URL}/profile`, {
        method: 'PUT',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${apiService.getCurrentUser()?.token}`
        },
        body: JSON.stringify(profileData)
      });

      if (!response.ok) {
        throw new Error(`Failed to update user profile: ${response.statusText}`);
      }

      return await response.json();
    } catch (error) {
      console.error('Error updating user profile:', error);
      throw error;
    }
  }
}

export const settingsApiService = new SettingsApiService();