// api.ts
const API_BASE_URL = 'http://localhost:8080/api';

export interface LoginRequest {
  email: string;
  password: string;
}

export interface RegisterRequest {
  name: string;
  email: string;
  password: string;
}

export interface AuthResponse {
  success: boolean;
  message: string;
  user?: {
    id: string;
    name: string;
    email: string;
    token?: string;
  };
  token?: string;
}

// API Service class
class ApiService {
  private async makeRequest<T>(
    url: string, 
    options: RequestInit = {}
  ): Promise<T> {
    const config: RequestInit = {
      headers: {
        'Content-Type': 'application/json',
        ...options.headers,
      },
      ...options,
    };

    // Add auth token if available
    const user = this.getStoredUser();
    if (user?.token) {
      config.headers = {
        ...config.headers,
        'Authorization': `Bearer ${user.token}`,
      };
    }

    try {
      const response = await fetch(`${API_BASE_URL}${url}`, config);

      if (response.status === 401) {
        this.logout();
        window.location.href = '/login';
        throw new Error('Unauthorized');
      }

      if (!response.ok) {
        const errorData = await response.json().catch(() => ({}));
        throw new Error(errorData.message || `HTTP error! status: ${response.status}`);
      }

      return await response.json();
    } catch (error) {
      console.error('API Request failed:', error);
      throw error;
    }
  }

  // Authentication methods
  async login(credentials: LoginRequest): Promise<AuthResponse> {
    const response = await this.makeRequest<AuthResponse>('/login', {
      method: 'POST',
      body: JSON.stringify(credentials),
    });

    if (response.success && response.user) {
      this.storeUser(response.user);
    }

    return response;
  }

  async register(userData: RegisterRequest): Promise<AuthResponse> {
    const response = await this.makeRequest<AuthResponse>('/register', {
      method: 'POST',
      body: JSON.stringify(userData),
    });

    if (response.success && response.user) {
      this.storeUser(response.user);
    }

    return response;
  }

  // User storage methods
  storeUser(user: AuthResponse['user']): void {
    if (typeof window !== 'undefined' && window.localStorage) {
      localStorage.setItem('user', JSON.stringify(user));
    }
  }

  getStoredUser(): AuthResponse['user'] | null {
    if (typeof window !== 'undefined' && window.localStorage) {
      const storedUser = localStorage.getItem('user');
      return storedUser ? JSON.parse(storedUser) : null;
    }
    return null;
  }

  clearStoredUser(): void {
    if (typeof window !== 'undefined' && window.localStorage) {
      localStorage.removeItem('user');
    }
  }

  logout(): void {
    this.clearStoredUser();
    // Optionally make a logout API call here
    // await this.makeRequest('/logout', { method: 'POST' });
  }

  // Check if user is authenticated
  isAuthenticated(): boolean {
    const user = this.getStoredUser();
    return !!(user && user.token);
  }

  // Get current user
  getCurrentUser(): AuthResponse['user'] | null {
    return this.getStoredUser();
  }
}

// Export singleton instance
export const apiService = new ApiService();

// Export individual methods for easier importing
export const {
  login,
  register,
  logout,
  isAuthenticated,
  getCurrentUser,
  storeUser,
  getStoredUser,
  clearStoredUser
} = apiService;