import React, { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { motion } from 'framer-motion';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import Navigation from '@/components/Navigation';
import { 
  Clock, 
  Calendar, 
  MessageSquare, 
  BarChart2, 
  CheckCircle, 
  XCircle,
  ArrowLeft,
  Lightbulb,
  Mic,
  BookOpen
} from 'lucide-react';
import { getSessionFeedback, getSession, PracticeSession, Feedback } from '@/apitest/sessionapi';
import { apiService } from '@/apitest/userapi';

const SessionDetail = () => {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const [session, setSession] = useState<PracticeSession | null>(null);
  const [feedback, setFeedback] = useState<Feedback | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    if (!apiService.isAuthenticated()) {
      navigate('/login');
    }
  }, [navigate]);

  useEffect(() => {
    const fetchSessionDetails = async () => {
      if (!id) return;
      
      try {
        setIsLoading(true);
        
        // Fetch both session details and feedback in parallel
        const [sessionData, feedbackData] = await Promise.all([
          getSession(id),
          getSessionFeedback(id)
        ]);
        
        setSession({
          ...sessionData,
          feedback: feedbackData
        });
        setFeedback(feedbackData);
      } catch (err) {
        console.error('Error fetching session details:', err);
        setError('Failed to load session details. Please try again later.');
      } finally {
        setIsLoading(false);
      }
    };

    fetchSessionDetails();
  }, [id]);

  // Format date for display
  const formatDate = (dateString: string | Date | undefined) => {
    if (!dateString) return 'N/A';
    const date = new Date(dateString);
    return date.toLocaleDateString('en-US', { 
      year: 'numeric', 
      month: 'short', 
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    });
  };

  // Calculate session duration
  const calculateDuration = (startTime: Date | string | undefined, endTime: Date | string | undefined) => {
    if (!startTime || !endTime) return 'N/A';
    
    const start = new Date(startTime);
    const end = new Date(endTime);
    const durationMs = end.getTime() - start.getTime();
    
    const minutes = Math.floor(durationMs / (1000 * 60));
    const seconds = Math.floor((durationMs % (1000 * 60)) / 1000);
    
    return `${minutes}m ${seconds}s`;
  };

  // Parse analysis data if it exists
  const parseAnalysis = () => {
    if (!feedback?.analysis) return null;
    try {
      return JSON.parse(feedback.analysis);
    } catch (e) {
      console.error('Error parsing analysis:', e);
      return null;
    }
  };

  const analysis = parseAnalysis();

  if (isLoading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-purple-50 via-blue-50 to-indigo-100 dark:from-gray-900 dark:via-purple-900 dark:to-blue-900">
        <Navigation />
        <div className="pt-20 px-4 pb-8 flex justify-center items-center h-[80vh]">
          <div className="w-12 h-12 border-4 border-primary border-t-transparent rounded-full animate-spin"></div>
        </div>
      </div>
    );
  }

  if (error || !session) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-purple-50 via-blue-50 to-indigo-100 dark:from-gray-900 dark:via-purple-900 dark:to-blue-900">
        <Navigation />
        <div className="pt-20 px-4 pb-8 container mx-auto text-center">
          <h1 className="text-2xl font-bold mb-4">Error</h1>
          <p className="text-red-500 mb-6">{error || 'Session not found'}</p>
          <Button onClick={() => navigate('/dashboard')}>Back to Dashboard</Button>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-50 via-blue-50 to-indigo-100 dark:from-gray-900 dark:via-purple-900 dark:to-blue-900">
      <Navigation />
      
      <div className="pt-20 px-4 pb-8">
        <div className="container mx-auto">
          {/* Session Header */}
          <motion.div
            initial={{ opacity: 0, y: -20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
            className="mb-6"
          >
            <Button 
              variant="ghost" 
              className="mb-4" 
              onClick={() => navigate('/dashboard')}
            >
              <ArrowLeft className="mr-2 h-4 w-4" /> Back to Dashboard
            </Button>
            
            <div className="flex flex-col md:flex-row justify-between items-start md:items-center">
              <div>
                <h1 className="text-3xl font-bold mb-2">{session.topic}</h1>
                <div className="flex flex-wrap items-center gap-3 text-sm text-muted-foreground">
                  <Badge variant="outline" className="text-primary border-primary">
                    {session.language}
                  </Badge>
                  <span className="flex items-center">
                    <Calendar className="w-4 h-4 mr-1" />
                    {formatDate(session.startTime)}
                  </span>
                  <span className="flex items-center">
                    <Clock className="w-4 h-4 mr-1" />
                    Duration: {calculateDuration(session.startTime, session.endTime)}
                  </span>
                  <Badge 
                    className={`${session.status === 'completed' 
                      ? 'bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-100' 
                      : 'bg-blue-100 text-blue-800 dark:bg-blue-900 dark:text-blue-100'}`}
                  >
                    {session.status}
                  </Badge>
                </div>
              </div>
              
              <div className="mt-4 md:mt-0 flex items-center bg-primary/10 p-3 rounded-lg">
                <div className="text-center mr-3">
                  <div className="text-3xl font-bold text-primary">{feedback?.score || 'N/A'}</div>
                  <div className="text-xs text-muted-foreground">Overall Score</div>
                </div>
                <div className="h-10 w-px bg-gray-300 dark:bg-gray-600 mx-3"></div>
                <div className="space-y-1">
                  <div className="flex items-center">
                    <span className="text-xs w-24">Grammar:</span>
                    <Progress value={feedback?.grammar || 0} className="h-2 w-24" />
                    <span className="text-xs ml-2">{feedback?.grammar || 0}</span>
                  </div>
                  <div className="flex items-center">
                    <span className="text-xs w-24">Pronunciation:</span>
                    <Progress value={feedback?.pronunciation || 0} className="h-2 w-24" />
                    <span className="text-xs ml-2">{feedback?.pronunciation || 0}</span>
                  </div>
                  <div className="flex items-center">
                    <span className="text-xs w-24">Fluency:</span>
                    <Progress value={feedback?.fluency || 0} className="h-2 w-24" />
                    <span className="text-xs ml-2">{feedback?.fluency || 0}</span>
                  </div>
                </div>
              </div>
            </div>
          </motion.div>

          {/* Session Content */}
          <Tabs defaultValue="transcript" className="w-full">
            <TabsList className="grid w-full md:w-auto grid-cols-3 md:grid-cols-4">
              <TabsTrigger value="transcript">Transcript</TabsTrigger>
              <TabsTrigger value="feedback">Feedback</TabsTrigger>
              <TabsTrigger value="corrections">Corrections</TabsTrigger>
              <TabsTrigger value="suggestions">Suggestions</TabsTrigger>
            </TabsList>
            
            <TabsContent value="transcript" className="mt-6">
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center">
                    <MessageSquare className="mr-2 h-5 w-5" />
                    Session Transcript
                  </CardTitle>
                  <CardDescription>
                    Complete transcript of your practice session
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  {feedback?.transcript ? (
                    <div className="bg-muted/50 p-4 rounded-md whitespace-pre-wrap">
                      {feedback.transcript}
                    </div>
                  ) : (
                    <div className="text-center text-muted-foreground p-8">
                      <MessageSquare className="h-12 w-12 mx-auto mb-4 opacity-20" />
                      <p>No transcript available for this session.</p>
                    </div>
                  )}
                </CardContent>
              </Card>
            </TabsContent>
            
            <TabsContent value="feedback" className="mt-6">
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center">
                    <BarChart2 className="mr-2 h-5 w-5" />
                    Performance Feedback
                  </CardTitle>
                  <CardDescription>
                    Detailed analysis of your language performance
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  {analysis ? (
                    <div className="space-y-6">
                      <div className="bg-muted/50 p-4 rounded-md">
                        <h3 className="font-semibold mb-2">Overall Feedback</h3>
                        <p>{analysis.overall_feedback}</p>
                      </div>
                      
                      <div className="grid md:grid-cols-3 gap-4">
                        <div className="bg-green-50 dark:bg-green-900/20 p-4 rounded-md">
                          <h3 className="font-semibold mb-2 flex items-center">
                            <CheckCircle className="h-4 w-4 mr-2 text-green-600" />
                            Strengths
                          </h3>
                          <ul className="list-disc list-inside space-y-1">
                            {analysis.strengths?.map((strength: string, i: number) => (
                              <li key={i}>{strength}</li>
                            )) || <li>No strengths identified</li>}
                          </ul>
                        </div>
                        
                        <div className="bg-red-50 dark:bg-red-900/20 p-4 rounded-md">
                          <h3 className="font-semibold mb-2 flex items-center">
                            <XCircle className="h-4 w-4 mr-2 text-red-600" />
                            Areas for Improvement
                          </h3>
                          <ul className="list-disc list-inside space-y-1">
                            {analysis.areas_for_improvement?.map((area: string, i: number) => (
                              <li key={i}>{area}</li>
                            )) || <li>No areas for improvement identified</li>}
                          </ul>
                        </div>
                        
                        <div className="bg-blue-50 dark:bg-blue-900/20 p-4 rounded-md">
                          <h3 className="font-semibold mb-2 flex items-center">
                            <Lightbulb className="h-4 w-4 mr-2 text-blue-600" />
                            Recommendations
                          </h3>
                          <ul className="list-disc list-inside space-y-1">
                            {analysis.recommendations?.map((rec: string, i: number) => (
                              <li key={i}>{rec}</li>
                            )) || <li>No recommendations available</li>}
                          </ul>
                        </div>
                      </div>
                    </div>
                  ) : (
                    <div className="text-center text-muted-foreground p-8">
                      <BarChart2 className="h-12 w-12 mx-auto mb-4 opacity-20" />
                      <p>No detailed feedback available for this session.</p>
                    </div>
                  )}
                </CardContent>
              </Card>
            </TabsContent>
            
            <TabsContent value="corrections" className="mt-6">
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center">
                    <CheckCircle className="mr-2 h-5 w-5" />
                    Grammar Corrections
                  </CardTitle>
                  <CardDescription>
                    Specific corrections to improve your language accuracy
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  {feedback?.corrections && feedback.corrections.length > 0 ? (
                    <div className="space-y-4">
                      {feedback.corrections.map((correction, index) => {
                        const parts = correction.split('→');
                        const original = parts[0]?.trim();
                        const corrected = parts[1]?.trim();
                        
                        return (
                          <div key={index} className="bg-muted/50 p-4 rounded-md">
                            <div className="flex flex-col md:flex-row md:items-center gap-2 md:gap-4">
                              <div className="flex-1">
                                <div className="text-xs text-muted-foreground mb-1">Original</div>
                                <div className="text-red-500 line-through">{original}</div>
                              </div>
                              <div className="hidden md:block text-muted-foreground">→</div>
                              <div className="flex-1">
                                <div className="text-xs text-muted-foreground mb-1">Corrected</div>
                                <div className="text-green-600">{corrected}</div>
                              </div>
                            </div>
                          </div>
                        );
                      })}
                    </div>
                  ) : (
                    <div className="text-center text-muted-foreground p-8">
                      <CheckCircle className="h-12 w-12 mx-auto mb-4 opacity-20" />
                      <p>No corrections needed for this session.</p>
                    </div>
                  )}
                </CardContent>
              </Card>
            </TabsContent>
            
            <TabsContent value="suggestions" className="mt-6">
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center">
                    <Lightbulb className="mr-2 h-5 w-5" />
                    Improvement Suggestions
                  </CardTitle>
                  <CardDescription>
                    Personalized suggestions to enhance your language skills
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  {session.suggestions && session.suggestions.length > 0 ? (
                    <div className="space-y-4">
                      {session.suggestions.map((suggestion, index) => (
                        <div key={index} className="bg-blue-50 dark:bg-blue-900/20 p-4 rounded-md">
                          <h3 className="font-semibold mb-2">Suggestion {index + 1}</h3>
                          <p>{suggestion}</p>
                        </div>
                      ))}
                    </div>
                  ) : (
                    <div className="text-center text-muted-foreground p-8">
                      <Lightbulb className="h-12 w-12 mx-auto mb-4 opacity-20" />
                      <p>No suggestions available for this session.</p>
                    </div>
                  )}
                  
                  <div className="mt-8">
                    <h3 className="font-semibold mb-4">Recommended Practice Resources</h3>
                    <div className="grid md:grid-cols-2 gap-4">
                      <div className="border rounded-md p-4">
                        <div className="flex items-center mb-2">
                          <BookOpen className="h-5 w-5 mr-2 text-primary" />
                          <h4 className="font-medium">Grammar Exercises</h4>
                        </div>
                        <p className="text-sm text-muted-foreground mb-3">Practice exercises focused on your weak areas</p>
                        <Button variant="outline" size="sm" className="w-full">View Exercises</Button>
                      </div>
                      
                      <div className="border rounded-md p-4">
                        <div className="flex items-center mb-2">
                          <Mic className="h-5 w-5 mr-2 text-primary" />
                          <h4 className="font-medium">Pronunciation Drills</h4>
                        </div>
                        <p className="text-sm text-muted-foreground mb-3">Audio exercises to improve your pronunciation</p>
                        <Button variant="outline" size="sm" className="w-full">Start Drills</Button>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </TabsContent>
          </Tabs>
        </div>
      </div>
    </div>
  );
};

export default SessionDetail;