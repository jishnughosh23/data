import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { motion } from 'framer-motion';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import Navigation from '@/components/Navigation';
import { Calendar, Search, ArrowLeft, MessageSquare, Filter } from 'lucide-react';
import { getUserSessions, PracticeSession } from '@/apitest/sessionapi';
import { apiService } from '@/apitest/userapi';

const SessionsList = () => {
  const navigate = useNavigate();
  const [sessions, setSessions] = useState<PracticeSession[]>([]);
  const [filteredSessions, setFilteredSessions] = useState<PracticeSession[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [searchTerm, setSearchTerm] = useState('');
  const [statusFilter, setStatusFilter] = useState('all');
  const [languageFilter, setLanguageFilter] = useState('all');
  const [sortBy, setSortBy] = useState('date-desc');

  useEffect(() => {
    if (!apiService.isAuthenticated()) {
      navigate('/login');
    }
  }, [navigate]);

  useEffect(() => {
    const fetchSessions = async () => {
      try {
        setIsLoading(true);
        const user = apiService.getCurrentUser();
        if (!user) {
          navigate('/login');
          return;
        }

        const sessionsData = await getUserSessions();
        setSessions(sessionsData);
        setFilteredSessions(sessionsData);
      } catch (err) {
        console.error('Error fetching sessions:', err);
        setError('Failed to load sessions. Please try again later.');
      } finally {
        setIsLoading(false);
      }
    };

    fetchSessions();
  }, [navigate]);

  useEffect(() => {
    // Apply filters and sorting
    let result = [...sessions];

    // Apply search filter
    if (searchTerm) {
      const term = searchTerm.toLowerCase();
      result = result.filter(session => 
        session.topic?.toLowerCase().includes(term) ||
        session.language?.toLowerCase().includes(term)
      );
    }

    // Apply status filter
    if (statusFilter !== 'all') {
      result = result.filter(session => session.status === statusFilter);
    }

    // Apply language filter
    if (languageFilter !== 'all') {
      result = result.filter(session => session.language === languageFilter);
    }

    // Apply sorting
    result.sort((a, b) => {
      const dateA = new Date(a.startTime || 0).getTime();
      const dateB = new Date(b.startTime || 0).getTime();
      
      switch (sortBy) {
        case 'date-asc':
          return dateA - dateB;
        case 'date-desc':
          return dateB - dateA;
        case 'score-asc':
          return (a.feedback?.score || 0) - (b.feedback?.score || 0);
        case 'score-desc':
          return (b.feedback?.score || 0) - (a.feedback?.score || 0);
        default:
          return dateB - dateA;
      }
    });

    setFilteredSessions(result);
  }, [sessions, searchTerm, statusFilter, languageFilter, sortBy]);

  // Format date for display
  const formatDate = (dateString: string | Date | undefined) => {
    if (!dateString) return 'N/A';
    const date = new Date(dateString);
    return date.toLocaleDateString('en-US', { 
      year: 'numeric', 
      month: 'short', 
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    });
  };

  // Calculate session duration
  const calculateDuration = (startTime: Date | string | undefined, endTime: Date | string | undefined) => {
    if (!startTime || !endTime) return 'N/A';
    
    const start = new Date(startTime);
    const end = new Date(endTime);
    const durationMs = end.getTime() - start.getTime();
    
    const minutes = Math.floor(durationMs / (1000 * 60));
    const seconds = Math.floor((durationMs % (1000 * 60)) / 1000);
    
    return `${minutes}m ${seconds}s`;
  };

  // Get unique languages for filter
  const languages = ['all', ...new Set(sessions.map(session => session.language).filter(Boolean))];

  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-50 via-blue-50 to-indigo-100 dark:from-gray-900 dark:via-purple-900 dark:to-blue-900">
      <Navigation />
      
      <div className="pt-20 px-4 pb-8">
        <div className="container mx-auto">
          <motion.div
            initial={{ opacity: 0, y: -20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
            className="mb-6"
          >
            <Button 
              variant="ghost" 
              className="mb-4" 
              onClick={() => navigate('/dashboard')}
            >
              <ArrowLeft className="mr-2 h-4 w-4" /> Back to Dashboard
            </Button>
            
            <div className="flex flex-col md:flex-row justify-between items-start md:items-center mb-6">
              <h1 className="text-3xl font-bold mb-4 md:mb-0 flex items-center">
                <Calendar className="w-6 h-6 mr-2 text-primary" />
                Practice Sessions
              </h1>
              
              <Button onClick={() => navigate('/practice')} className="bg-primary hover:bg-primary/90">
                Start New Session
              </Button>
            </div>
          </motion.div>

          <Card className="bg-white/80 dark:bg-gray-800/80 backdrop-blur-sm border-0 shadow-lg mb-8">
            <CardHeader>
              <CardTitle className="flex items-center">
                <Filter className="w-5 h-5 mr-2 text-primary" />
                Filters and Search
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
                <div>
                  <div className="text-sm font-medium mb-2">Search</div>
                  <div className="relative">
                    <Search className="absolute left-2 top-2.5 h-4 w-4 text-muted-foreground" />
                    <Input
                      placeholder="Search by topic or language"
                      className="pl-8"
                      value={searchTerm}
                      onChange={(e) => setSearchTerm(e.target.value)}
                    />
                  </div>
                </div>
                
                <div>
                  <div className="text-sm font-medium mb-2">Status</div>
                  <Select value={statusFilter} onValueChange={setStatusFilter}>
                    <SelectTrigger>
                      <SelectValue placeholder="Filter by status" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">All Statuses</SelectItem>
                      <SelectItem value="completed">Completed</SelectItem>
                      <SelectItem value="active">Active</SelectItem>
                      <SelectItem value="cancelled">Cancelled</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                
                <div>
                  <div className="text-sm font-medium mb-2">Language</div>
                  <Select value={languageFilter} onValueChange={setLanguageFilter}>
                    <SelectTrigger>
                      <SelectValue placeholder="Filter by language" />
                    </SelectTrigger>
                    <SelectContent>
                      {languages.map((lang) => (
                        <SelectItem key={lang} value={lang}>
                          {lang === 'all' ? 'All Languages' : lang}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                
                <div>
                  <div className="text-sm font-medium mb-2">Sort By</div>
                  <Select value={sortBy} onValueChange={setSortBy}>
                    <SelectTrigger>
                      <SelectValue placeholder="Sort by" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="date-desc">Newest First</SelectItem>
                      <SelectItem value="date-asc">Oldest First</SelectItem>
                      <SelectItem value="score-desc">Highest Score</SelectItem>
                      <SelectItem value="score-asc">Lowest Score</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card className="bg-white/80 dark:bg-gray-800/80 backdrop-blur-sm border-0 shadow-lg">
            <CardContent className="p-6">
              {isLoading ? (
                <div className="flex justify-center items-center p-8">
                  <div className="w-8 h-8 border-4 border-primary border-t-transparent rounded-full animate-spin"></div>
                </div>
              ) : error ? (
                <div className="text-center text-red-500 p-4">{error}</div>
              ) : filteredSessions.length === 0 ? (
                <div className="text-center text-muted-foreground p-8">
                  <MessageSquare className="h-12 w-12 mx-auto mb-4 opacity-20" />
                  {searchTerm || statusFilter !== 'all' || languageFilter !== 'all' ? (
                    <>
                      <p>No sessions match your filters.</p>
                      <Button 
                        variant="outline" 
                        className="mt-4" 
                        onClick={() => {
                          setSearchTerm('');
                          setStatusFilter('all');
                          setLanguageFilter('all');
                        }}
                      >
                        Clear Filters
                      </Button>
                    </>
                  ) : (
                    <>
                      <p>You haven't completed any practice sessions yet.</p>
                      <Button className="mt-4" onClick={() => navigate('/practice')}>
                        Start Practicing
                      </Button>
                    </>
                  )}
                </div>
              ) : (
                <div className="overflow-x-auto">
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>Date</TableHead>
                        <TableHead>Topic</TableHead>
                        <TableHead>Language</TableHead>
                        <TableHead>Duration</TableHead>
                        <TableHead>Status</TableHead>
                        <TableHead>Score</TableHead>
                        <TableHead>Actions</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {filteredSessions.map((session) => (
                        <TableRow key={session.id}>
                          <TableCell>{formatDate(session.startTime || '')}</TableCell>
                          <TableCell>{session.topic}</TableCell>
                          <TableCell>{session.language}</TableCell>
                          <TableCell>
                            {calculateDuration(session.startTime || '', session.endTime || '')}
                          </TableCell>
                          <TableCell>
                            <Badge 
                              className={`${session.status === 'completed' 
                                ? 'bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-100' 
                                : session.status === 'active' 
                                ? 'bg-blue-100 text-blue-800 dark:bg-blue-900 dark:text-blue-100' 
                                : 'bg-gray-100 text-gray-800 dark:bg-gray-800 dark:text-gray-200'}`}
                            >
                              {session.status}
                            </Badge>
                          </TableCell>
                          <TableCell>
                            {session.feedback?.score || 'N/A'}
                          </TableCell>
                          <TableCell>
                            <Button 
                              variant="outline" 
                              size="sm"
                              onClick={() => navigate(`/session/${session.id}`)}
                            >
                              View Details
                            </Button>
                          </TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                  <div className="mt-4 text-sm text-muted-foreground text-center">
                    Showing {filteredSessions.length} of {sessions.length} sessions
                  </div>
                </div>
              )}
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
};

export default SessionsList;