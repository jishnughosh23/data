import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Progress } from '@/components/ui/progress';
import { useLocation, useNavigate } from 'react-router-dom';
import { Badge } from '@/components/ui/badge';
import { Separator } from '@/components/ui/separator';
import { Alert, AlertDescription, AlertTitle } from '@/components/ui/alert';
import { toast } from '@/components/ui/use-toast';
import Navigation from '@/components/Navigation';
import { apiService } from '@/apitest/userapi';
import { Trophy, Star, Clock, CheckCircle, XCircle, HelpCircle, ArrowRight, ArrowLeft } from 'lucide-react';

interface GameQuestion {
  id: number;
  question: string;
  options: string[];
  correctAnswer: string;
  explanation: string;
}

interface GameLevel {
  id: number;
  title: string;
  description: string;
  questions: GameQuestion[];
  isCompleted: boolean;
  score: number;
}

const Game = () => {
  const location = useLocation();
  const navigate = useNavigate();
  const { state } = location as { state?: { language?: string } };
  const [currentUser, setCurrentUser] = useState(apiService.getCurrentUser());
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [levels, setLevels] = useState<GameLevel[]>([]);
  const [currentLevel, setCurrentLevel] = useState<number>(0);
  const [currentQuestion, setCurrentQuestion] = useState<number>(0);
  const [selectedAnswer, setSelectedAnswer] = useState<string | null>(null);
  const [isAnswerChecked, setIsAnswerChecked] = useState(false);
  const [score, setScore] = useState(0);
  const [gameCompleted, setGameCompleted] = useState(false);
  const [gameStarted, setGameStarted] = useState(false);
  
  // Mock data for game levels
  useEffect(() => {
    const fetchGameLevels = async () => {
      setIsLoading(true);
      try {
        // In a real app, this would be an API call to fetch levels for the selected language
        // For now, we'll use mock data
        const mockLevels: GameLevel[] = [
          {
            id: 1,
            title: 'Level 1: Basics',
            description: 'Learn basic vocabulary and phrases',
            isCompleted: false,
            score: 0,
            questions: [
              {
                id: 1,
                question: 'What is "Hello" in ' + (state?.language || 'Spanish') + '?',
                options: ['Hola', 'Adiós', 'Gracias', 'Por favor'],
                correctAnswer: 'Hola',
                explanation: '"Hola" is the Spanish word for "Hello".',
              },
              {
                id: 2,
                question: 'What is "Thank you" in ' + (state?.language || 'Spanish') + '?',
                options: ['Hola', 'Adiós', 'Gracias', 'Por favor'],
                correctAnswer: 'Gracias',
                explanation: '"Gracias" is the Spanish word for "Thank you".',
              },
              {
                id: 3,
                question: 'What is "Goodbye" in ' + (state?.language || 'Spanish') + '?',
                options: ['Hola', 'Adiós', 'Gracias', 'Por favor'],
                correctAnswer: 'Adiós',
                explanation: '"Adiós" is the Spanish word for "Goodbye".',
              },
            ],
          },
          {
            id: 2,
            title: 'Level 2: Greetings',
            description: 'Learn common greetings and introductions',
            isCompleted: false,
            score: 0,
            questions: [
              {
                id: 1,
                question: 'How do you say "Good morning" in ' + (state?.language || 'Spanish') + '?',
                options: ['Buenos días', 'Buenas tardes', 'Buenas noches', 'Buen provecho'],
                correctAnswer: 'Buenos días',
                explanation: '"Buenos días" is the Spanish phrase for "Good morning".',
              },
              {
                id: 2,
                question: 'How do you say "Good afternoon" in ' + (state?.language || 'Spanish') + '?',
                options: ['Buenos días', 'Buenas tardes', 'Buenas noches', 'Buen provecho'],
                correctAnswer: 'Buenas tardes',
                explanation: '"Buenas tardes" is the Spanish phrase for "Good afternoon".',
              },
              {
                id: 3,
                question: 'How do you say "Good night" in ' + (state?.language || 'Spanish') + '?',
                options: ['Buenos días', 'Buenas tardes', 'Buenas noches', 'Buen provecho'],
                correctAnswer: 'Buenas noches',
                explanation: '"Buenas noches" is the Spanish phrase for "Good night".',
              },
            ],
          },
          {
            id: 3,
            title: 'Level 3: Numbers',
            description: 'Learn to count in ' + (state?.language || 'Spanish'),
            isCompleted: false,
            score: 0,
            questions: [
              {
                id: 1,
                question: 'What is the number "1" in ' + (state?.language || 'Spanish') + '?',
                options: ['Uno', 'Dos', 'Tres', 'Cuatro'],
                correctAnswer: 'Uno',
                explanation: '"Uno" is the Spanish word for the number "1".',
              },
              {
                id: 2,
                question: 'What is the number "2" in ' + (state?.language || 'Spanish') + '?',
                options: ['Uno', 'Dos', 'Tres', 'Cuatro'],
                correctAnswer: 'Dos',
                explanation: '"Dos" is the Spanish word for the number "2".',
              },
              {
                id: 3,
                question: 'What is the number "3" in ' + (state?.language || 'Spanish') + '?',
                options: ['Uno', 'Dos', 'Tres', 'Cuatro'],
                correctAnswer: 'Tres',
                explanation: '"Tres" is the Spanish word for the number "3".',
              },
            ],
          },
        ];
        
        setLevels(mockLevels);
      } catch (error) {
        console.error('Error fetching game levels:', error);
        setError('Failed to load game levels. Please try again later.');
      } finally {
        setIsLoading(false);
      }
    };
    
    fetchGameLevels();
  }, [state?.language]);
  
  const startGame = () => {
    setGameStarted(true);
    setCurrentLevel(0);
    setCurrentQuestion(0);
    setScore(0);
    setGameCompleted(false);
    setSelectedAnswer(null);
    setIsAnswerChecked(false);
  };
  
  const handleAnswerSelect = (answer: string) => {
    if (isAnswerChecked) return;
    setSelectedAnswer(answer);
  };
  
  const checkAnswer = () => {
    if (!selectedAnswer || isAnswerChecked) return;
    
    const currentQuestionObj = levels[currentLevel].questions[currentQuestion];
    const isCorrect = selectedAnswer === currentQuestionObj.correctAnswer;
    
    if (isCorrect) {
      setScore(score + 1);
      toast({
        title: 'Correct!',
        description: currentQuestionObj.explanation,
        variant: 'default',
      });
    } else {
      toast({
        title: 'Incorrect',
        description: `The correct answer is "${currentQuestionObj.correctAnswer}". ${currentQuestionObj.explanation}`,
        variant: 'destructive',
      });
    }
    
    setIsAnswerChecked(true);
  };
  
  const nextQuestion = () => {
    const currentLevelObj = levels[currentLevel];
    
    if (currentQuestion < currentLevelObj.questions.length - 1) {
      // Move to next question in current level
      setCurrentQuestion(currentQuestion + 1);
      setSelectedAnswer(null);
      setIsAnswerChecked(false);
    } else {
      // Level completed
      const updatedLevels = [...levels];
      updatedLevels[currentLevel].isCompleted = true;
      updatedLevels[currentLevel].score = score;
      setLevels(updatedLevels);
      
      if (currentLevel < levels.length - 1) {
        // Move to next level
        setCurrentLevel(currentLevel + 1);
        setCurrentQuestion(0);
        setSelectedAnswer(null);
        setIsAnswerChecked(false);
        toast({
          title: 'Level Completed!',
          description: `You've completed ${currentLevelObj.title} with a score of ${score}/${currentLevelObj.questions.length}`,
          variant: 'default',
        });
      } else {
        // Game completed
        setGameCompleted(true);
        toast({
          title: 'Game Completed!',
          description: `Congratulations! You've completed all levels with a total score of ${score}/${levels.reduce((total, level) => total + level.questions.length, 0)}`,
          variant: 'default',
        });
      }
    }
  };
  
  const saveProgress = async () => {
    // In a real app, this would save the game progress to the database
    // For now, we'll just show a toast
    toast({
      title: 'Progress Saved',
      description: 'Your game progress has been saved successfully.',
      variant: 'default',
    });
    
    // Navigate back to dashboard
    navigate('/dashboard');
  };
  
  if (isLoading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-purple-50 via-blue-50 to-indigo-100 dark:from-gray-900 dark:via-purple-900 dark:to-blue-900 pt-20 px-4 pb-8">
        <Navigation />
        <div className="container mx-auto max-w-4xl text-center py-20">
          <div className="animate-pulse">
            <div className="h-8 bg-gray-200 dark:bg-gray-700 rounded w-1/3 mx-auto mb-4"></div>
            <div className="h-4 bg-gray-200 dark:bg-gray-700 rounded w-1/2 mx-auto mb-8"></div>
            <div className="h-64 bg-gray-200 dark:bg-gray-700 rounded mb-4"></div>
          </div>
        </div>
      </div>
    );
  }
  
  if (error) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-purple-50 via-blue-50 to-indigo-100 dark:from-gray-900 dark:via-purple-900 dark:to-blue-900 pt-20 px-4 pb-8">
        <Navigation />
        <div className="container mx-auto max-w-4xl py-20">
          <Alert variant="destructive">
            <AlertTitle>Error</AlertTitle>
            <AlertDescription>{error}</AlertDescription>
          </Alert>
          <div className="mt-8 text-center">
            <Button onClick={() => navigate('/dashboard')}>Return to Dashboard</Button>
          </div>
        </div>
      </div>
    );
  }
  
  if (!gameStarted) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-purple-50 via-blue-50 to-indigo-100 dark:from-gray-900 dark:via-purple-900 dark:to-blue-900 pt-20 px-4 pb-8">
        <Navigation />
        <div className="container mx-auto max-w-4xl">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
            className="mb-8 text-center py-10"
          >
            <h1 className="text-3xl md:text-4xl font-bold mb-4">
              Game-Based Learning: {state?.language || 'Spanish'}
            </h1>
            <p className="text-xl text-muted-foreground mb-8">
              Master {state?.language || 'Spanish'} through fun interactive games
            </p>
            
            <div className="grid gap-6 md:grid-cols-3 mb-8">
              {levels.map((level, index) => (
                <Card key={level.id} className="bg-white/80 dark:bg-gray-800/80 backdrop-blur-sm border-0 shadow-lg">
                  <CardHeader>
                    <CardTitle className="flex items-center justify-between">
                      {level.title}
                      {level.isCompleted && <Trophy className="w-5 h-5 text-yellow-500" />}
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <p className="text-muted-foreground mb-4">{level.description}</p>
                    <div className="flex items-center justify-between mb-2">
                      <span className="text-sm">{level.questions.length} Questions</span>
                      {level.isCompleted && (
                        <span className="text-sm font-medium">
                          Score: {level.score}/{level.questions.length}
                        </span>
                      )}
                    </div>
                    {level.isCompleted ? (
                      <Progress value={(level.score / level.questions.length) * 100} className="h-2" />
                    ) : (
                      <Progress value={0} className="h-2" />
                    )}
                  </CardContent>
                </Card>
              ))}
            </div>
            
            <Button 
              size="lg" 
              onClick={startGame}
              className="bg-gradient-to-r from-purple-600 to-blue-600 hover:from-purple-700 hover:to-blue-700 text-white px-8 py-6 text-lg"
            >
              Start Game
            </Button>
          </motion.div>
        </div>
      </div>
    );
  }
  
  if (gameCompleted) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-purple-50 via-blue-50 to-indigo-100 dark:from-gray-900 dark:via-purple-900 dark:to-blue-900 pt-20 px-4 pb-8">
        <Navigation />
        <div className="container mx-auto max-w-4xl">
          <motion.div
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ duration: 0.8 }}
            className="text-center py-10"
          >
            <div className="mb-8">
              <Trophy className="w-20 h-20 text-yellow-500 mx-auto mb-4" />
              <h1 className="text-3xl md:text-4xl font-bold mb-4">
                Congratulations!
              </h1>
              <p className="text-xl text-muted-foreground mb-8">
                You've completed all levels of {state?.language || 'Spanish'} game-based learning
              </p>
            </div>
            
            <Card className="bg-white/80 dark:bg-gray-800/80 backdrop-blur-sm border-0 shadow-lg mb-8">
              <CardHeader>
                <CardTitle>Your Results</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {levels.map((level) => (
                    <div key={level.id} className="flex items-center justify-between">
                      <span>{level.title}</span>
                      <Badge variant="outline" className="ml-auto">
                        {level.score}/{level.questions.length} correct
                      </Badge>
                    </div>
                  ))}
                  
                  <Separator className="my-4" />
                  
                  <div className="flex items-center justify-between font-bold">
                    <span>Total Score</span>
                    <Badge variant="default" className="ml-auto">
                      {score}/{levels.reduce((total, level) => total + level.questions.length, 0)} correct
                    </Badge>
                  </div>
                </div>
              </CardContent>
            </Card>
            
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Button variant="outline" onClick={() => navigate('/dashboard')}>
                <ArrowLeft className="w-4 h-4 mr-2" />
                Return to Dashboard
              </Button>
              <Button onClick={saveProgress}>
                <CheckCircle className="w-4 h-4 mr-2" />
                Save Progress
              </Button>
              <Button onClick={startGame} variant="default">
                <ArrowRight className="w-4 h-4 mr-2" />
                Play Again
              </Button>
            </div>
          </motion.div>
        </div>
      </div>
    );
  }
  
  // Game in progress
  const currentLevelObj = levels[currentLevel];
  const currentQuestionObj = currentLevelObj.questions[currentQuestion];
  
  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-50 via-blue-50 to-indigo-100 dark:from-gray-900 dark:via-purple-900 dark:to-blue-900 pt-20 px-4 pb-8">
      <Navigation />
      <div className="container mx-auto max-w-4xl">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
          className="mb-8"
        >
          <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center mb-6">
            <div>
              <h1 className="text-2xl font-bold mb-1">{currentLevelObj.title}</h1>
              <p className="text-muted-foreground">{currentLevelObj.description}</p>
            </div>
            <div className="mt-4 sm:mt-0">
              <Badge variant="outline" className="text-lg">
                Question {currentQuestion + 1}/{currentLevelObj.questions.length}
              </Badge>
            </div>
          </div>
          
          <Card className="bg-white/80 dark:bg-gray-800/80 backdrop-blur-sm border-0 shadow-lg mb-8">
            <CardContent className="p-6">
              <h2 className="text-xl font-semibold mb-6">{currentQuestionObj.question}</h2>
              
              <div className="space-y-4">
                {currentQuestionObj.options.map((option) => (
                  <div
                    key={option}
                    onClick={() => handleAnswerSelect(option)}
                    className={`p-4 rounded-lg border-2 cursor-pointer transition-all ${
                      selectedAnswer === option
                        ? isAnswerChecked
                          ? option === currentQuestionObj.correctAnswer
                            ? 'border-green-500 bg-green-50 dark:bg-green-900/20'
                            : 'border-red-500 bg-red-50 dark:bg-red-900/20'
                          : 'border-primary bg-primary/10'
                        : 'border-border hover:border-primary/50'
                    }`}
                  >
                    <div className="flex items-center">
                      <div className="mr-3">
                        {isAnswerChecked ? (
                          option === currentQuestionObj.correctAnswer ? (
                            <CheckCircle className="w-5 h-5 text-green-500" />
                          ) : selectedAnswer === option ? (
                            <XCircle className="w-5 h-5 text-red-500" />
                          ) : (
                            <div className="w-5 h-5 rounded-full border-2 border-gray-300" />
                          )
                        ) : selectedAnswer === option ? (
                          <div className="w-5 h-5 rounded-full bg-primary" />
                        ) : (
                          <div className="w-5 h-5 rounded-full border-2 border-gray-300" />
                        )}
                      </div>
                      <span>{option}</span>
                    </div>
                  </div>
                ))}
              </div>
              
              {isAnswerChecked && (
                <div className="mt-6 p-4 bg-gray-50 dark:bg-gray-800 rounded-lg">
                  <p className="font-medium mb-2">
                    {selectedAnswer === currentQuestionObj.correctAnswer ? (
                      <span className="text-green-600 dark:text-green-400 flex items-center">
                        <CheckCircle className="w-5 h-5 mr-2" /> Correct!
                      </span>
                    ) : (
                      <span className="text-red-600 dark:text-red-400 flex items-center">
                        <XCircle className="w-5 h-5 mr-2" /> Incorrect
                      </span>
                    )}
                  </p>
                  <p>{currentQuestionObj.explanation}</p>
                </div>
              )}
            </CardContent>
          </Card>
          
          <div className="flex justify-between">
            <Button 
              variant="outline" 
              onClick={() => navigate('/dashboard')}
            >
              Exit Game
            </Button>
            
            <div className="space-x-4">
              {!isAnswerChecked ? (
                <Button 
                  onClick={checkAnswer} 
                  disabled={!selectedAnswer}
                >
                  Check Answer
                </Button>
              ) : (
                <Button 
                  onClick={nextQuestion}
                  className="bg-gradient-to-r from-purple-600 to-blue-600 hover:from-purple-700 hover:to-blue-700"
                >
                  {currentQuestion < currentLevelObj.questions.length - 1 ? 'Next Question' : currentLevel < levels.length - 1 ? 'Next Level' : 'Finish Game'}
                  <ArrowRight className="w-4 h-4 ml-2" />
                </Button>
              )}
            </div>
          </div>
        </motion.div>
      </div>
    </div>
  );
};

export default Game;