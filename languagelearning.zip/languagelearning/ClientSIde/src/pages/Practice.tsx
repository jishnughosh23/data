import React, { useState, useEffect, useRef } from 'react';
import { motion } from 'framer-motion';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import Navigation from '@/components/Navigation';
import { 
  Mic, 
  MicOff, 
  Video, 
  VideoOff, 
  Phone, 
  MessageSquare, 
  Settings,
  Volume2,
  VolumeX,
  RotateCcw,
  ThumbsUp,
  ThumbsDown,
  AlertCircle,
  CheckCircle,
  Lightbulb,
  UserPlus,
  StopCircle
} from 'lucide-react';
import { useLocation, useNavigate } from 'react-router-dom';
import { AspectRatio } from '@/components/ui/aspect-ratio';
import { apiService } from '@/apitest/userapi';
import { startSession, endSession, PracticeSession, Feedback } from '@/apitest/sessionapi';

interface HRQuestion {
  question: string;
  context?: string;
  feedback?: string;
  timestamp: string;
}

interface RealTimeFeedback {
  type: 'grammar' | 'pronunciation' | 'fluency' | 'vocabulary';
  message: string;
  timestamp: string;
  severity: 'info' | 'warning' | 'error';
}

const Practice = () => {
  const location = useLocation();
  const navigate = useNavigate();
  const { state } = location as { state?: { language?: string; mode?: string; topic?: string } };
  const [isMicOn, setIsMicOn] = useState(true);
  const [isVideoOn, setIsVideoOn] = useState(true);
  const [isAudioOn, setIsAudioOn] = useState(true);
  const [isCallActive, setIsCallActive] = useState(false);
  const [user, setUser] = useState(null);
  const [videoStream, setVideoStream] = useState<MediaStream | null>(null);
  const videoRef = useRef<HTMLVideoElement>(null);
  const [transcript, setTranscript] = useState<any[]>([]);
  const [isTranscribing, setIsTranscribing] = useState(false);
  const mediaRecorderRef = useRef<MediaRecorder | null>(null);
  const audioChunksRef = useRef<Blob[]>([]);
  const [analysis, setAnalysis] = useState<any>(null);
  const [isAnalysing, setIsAnalysing] = useState(false);
  const [analysisError, setAnalysisError] = useState<string | null>(null);
  const [aiTranscriptSuggestions, setAiTranscriptSuggestions] = useState<any[]>([]);
  const [isInterviewMode, setIsInterviewMode] = useState(false);
  const [hrQuestions, setHrQuestions] = useState<HRQuestion[]>([]);
  const [realTimeFeedback, setRealTimeFeedback] = useState<RealTimeFeedback[]>([]);
  const [isGeneratingQuestion, setIsGeneratingQuestion] = useState(false);
  const interviewTimeoutRef = useRef<NodeJS.Timeout | null>(null);
  const [currentSession, setCurrentSession] = useState<PracticeSession | null>(null);
  const [isSavingSession, setIsSavingSession] = useState(false);

  const currentTopic = state?.topic || "Job Interview Practice";
  const currentLanguage = state?.language || "English";
  const sessionDuration = 1245; // seconds
  const [timeRemaining, setTimeRemaining] = useState(sessionDuration);

  // API Keys - Replace with your actual keys
  const GROQ_API_KEY = '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';
  const OPENAI_API_KEY='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'// Replace with your OpenAI API key

  useEffect(() => {
    if (!apiService.isAuthenticated()) {
      navigate('/login');
    }
  }, [navigate]);

  useEffect(() => {
    const interval = setInterval(() => {
      setTimeRemaining(prev => prev > 0 ? prev - 1 : 0);
    }, 1000);
    return () => clearInterval(interval);
  }, []);

  useEffect(() => {
    if (state?.mode === 'basic') {
      setIsCallActive(true);
    }
  }, [state]);
  
  // Start a new practice session when the call becomes active
  useEffect(() => {
    const initSession = async () => {
      if (isCallActive && user) {
        try {
          const sessionData: PracticeSession = {
            userId: user.id,
            language: currentLanguage,
            topic: currentTopic,
            status: 'active',
            questions: [],
            suggestions: []
          };
          
          const session = await startSession(sessionData);
          setCurrentSession(session);
          console.log('Practice session started:', session);
        } catch (error) {
          console.error('Failed to start practice session:', error);
        }
      }
    };
    
    initSession();
  }, [isCallActive, user, currentLanguage, currentTopic]);

  useEffect(() => {
    setUser(apiService.getCurrentUser());
  }, []);

  useEffect(() => {
    if (isVideoOn && user) {
      navigator.mediaDevices.getUserMedia({ video: true, audio: false })
        .then(stream => {
          setVideoStream(stream);
          if (videoRef.current) {
            videoRef.current.srcObject = stream;
          }
        })
        .catch(err => {
          setVideoStream(null);
        });
    } else {
      if (videoStream) {
        videoStream.getTracks().forEach(track => track.stop());
        setVideoStream(null);
      }
    }
    return () => {
      if (videoStream) {
        videoStream.getTracks().forEach(track => track.stop());
      }
    };
  }, [isVideoOn, user]);

  useEffect(() => {
    if (videoRef.current && videoStream) {
      videoRef.current.srcObject = videoStream;
    }
  }, [videoStream]);

  // Enhanced Whisper API integration with Groq
  async function transcribeAudioWithWhisper(audioBlob: Blob): Promise<string> {
    try {
      const formData = new FormData();
      formData.append('file', audioBlob, 'audio.webm');
      formData.append('model', 'whisper-large-v3');
      formData.append('response_format', 'json');
      formData.append('language', 'en');
      formData.append('temperature', '0');

      const response = await fetch('https://api.groq.com/openai/v1/audio/transcriptions', {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${GROQ_API_KEY}`
        },
        body: formData
      });

      if (!response.ok) {
        throw new Error(`Groq API error: ${response.status}`);
      }

      const data = await response.json();
      const text = data.text || '';
      
      // Only return if there's meaningful content
      const cleanText = text.trim();
      if (cleanText && cleanText !== '.' && cleanText !== ',' && !cleanText.toLowerCase().includes('thank you')) {
        return cleanText;
      }
      return '';
    } catch (err) {
      console.error('Whisper transcription error:', err);
      return '';
    }
  }

  // Enhanced OpenAI Grammar Analysis
  async function analyzeGrammarWithOpenAI(text: string) {
    try {
      const response = await fetch('https://api.openai.com/v1/chat/completions', {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${OPENAI_API_KEY}`,
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({
          model: 'gpt-4',
          messages: [
            {
              role: 'system',
              content: `You are a grammar and language expert. Analyze the given text for grammar errors, suggest corrections, and provide modernization tips. Return a JSON response with:
              {
                "words": [{"word": "text", "correct": true/false, "correction": "corrected version if incorrect", "explanation": "why it's wrong"}],
                "suggestions": [{"original": "old phrase", "modern": "modern alternative", "reason": "explanation"}],
                "overall_feedback": "general feedback on speaking style"
              }`
            },
            {
              role: 'user',
              content: `Please analyze this text: "${text}"`
            }
          ],
          temperature: 0.3,
          max_tokens: 1500
        })
      });

      if (!response.ok) {
        throw new Error(`OpenAI API error: ${response.status}`);
      }

      const data = await response.json();
      const content = data.choices[0].message.content;
      
      try {
        return JSON.parse(content);
      } catch (parseError) {
        // Fallback if JSON parsing fails
        return {
          words: text.split(/\s+/).map(word => ({ word, correct: true, correction: null, explanation: null })),
          suggestions: [],
          overall_feedback: "Unable to analyze at this time."
        };
      }
    } catch (err) {
      console.error('OpenAI analysis error:', err);
      throw err;
    }
  }

  // Start/stop recording audio for Whisper
  useEffect(() => {
    let mediaRecorder: MediaRecorder | null = null;
    let stopped = false;
    let audioStream: MediaStream | null = null;
    
    if (isMicOn && isCallActive && user) {
      navigator.mediaDevices.getUserMedia({ audio: true })
        .then(stream => {
          audioStream = stream;
          mediaRecorder = new MediaRecorder(stream, {
            mimeType: 'audio/webm;codecs=opus'
          });
          mediaRecorderRef.current = mediaRecorder;
          audioChunksRef.current = [];

          mediaRecorder.ondataavailable = (event) => {
            audioChunksRef.current.push(event.data);
          };

          mediaRecorder.onstop = async () => {
            const audioBlob = new Blob(audioChunksRef.current, { type: 'audio/webm' });
            
            // Only process if audio blob has meaningful size
            if (audioBlob.size > 1000) {
              setIsTranscribing(true);
              const text = await transcribeAudioWithWhisper(audioBlob);
              setIsTranscribing(false);

              // Only add to transcript if there's meaningful content
              if (text) {
                setTranscript(prev => {
                  // If the last transcript was less than 2 seconds ago, combine with it
                  if (prev.length > 0) {
                    const lastTranscript = prev[prev.length - 1];
                    const timeSinceLastTranscript = Date.now() - new Date(lastTranscript.timestamp).getTime();
                    
                    if (timeSinceLastTranscript < 2000) {
                      // Combine with previous transcript
                      const updatedTranscripts = [...prev];
                      updatedTranscripts[updatedTranscripts.length - 1] = {
                        ...lastTranscript,
                        text: `${lastTranscript.text} ${text}`
                      };
                      return updatedTranscripts;
                    }
                  }
                  
                  // Add as new transcript
                  return [...prev, {
                    speaker: user.name || 'You',
                    text,
                    timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
                  }];
                });
              }
            }
            
            audioChunksRef.current = [];
            
            // Restart recording for next chunk
            if (isMicOn && isCallActive && user && !stopped) {
              setTimeout(() => {
                if (mediaRecorderRef.current && mediaRecorderRef.current.state === 'inactive') {
                  mediaRecorderRef.current.start();
                  setTimeout(() => {
                    if (mediaRecorderRef.current && mediaRecorderRef.current.state === 'recording') {
                      mediaRecorderRef.current.stop();
                    }
                  }, 5000); // 5 seconds per chunk for better accuracy
                }
              }, 300);
            }
          };

          mediaRecorder.start();
          setTimeout(() => {
            if (mediaRecorder && mediaRecorder.state === 'recording') {
              mediaRecorder.stop();
            }
          }, 5000); // 5 seconds per chunk
        })
        .catch(err => {
          console.error('Media access error:', err);
        });
      
      return () => {
        stopped = true;
        if (mediaRecorderRef.current && mediaRecorderRef.current.state === 'recording') {
          mediaRecorderRef.current.stop();
        }
        if (audioStream) {
          audioStream.getTracks().forEach(track => track.stop());
        }
      };
    }
  }, [isMicOn, isCallActive, user]);

  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins}:${secs.toString().padStart(2, '0')}`;
  };

  const feedback = {
    grammar: 92,
    pronunciation: 88,
    fluency: 85,
    vocabulary: 90
  };

  // Enhanced Analysis Handler
  const handleAnalyse = async () => {
    setIsAnalysing(true);
    setAnalysisError(null);
    setAnalysis(null);
    setAiTranscriptSuggestions([]);
    
    try {
      const allText = transcript.map(t => t.text).join(' ');
      if (!allText.trim()) {
        setAnalysisError('No transcript to analyze. Please speak something first.');
        setIsAnalysing(false);
        return;
      }

      const result = await analyzeGrammarWithOpenAI(allText);
      setAnalysis(result);
      
      // Set AI suggestions based on the analysis
      if (result.suggestions && result.suggestions.length > 0) {
        setAiTranscriptSuggestions(result.suggestions.map(s => ({
          original: s.original,
          suggestion: s.modern,
          tip: s.reason
        })));
      }
      
      // Update session with suggestions if we have an active session
      if (currentSession?.id && result.suggestions && result.suggestions.length > 0) {
        const suggestions = result.suggestions.map(s => `${s.original} → ${s.modern}: ${s.reason}`);
        setCurrentSession(prev => prev ? {
          ...prev,
          suggestions: [...(prev.suggestions || []), ...suggestions]
        } : null);
      }
      
    } catch (err) {
      console.error('Analysis error:', err);
      setAnalysisError('Failed to analyze transcript. Please check your OpenAI API key and try again.');
    }
    
    setIsAnalysing(false);
  };

  // Generate HR interview questions
  const generateHRQuestion = async () => {
    if (!isInterviewMode || !user) return;
    
    setIsGeneratingQuestion(true);
    try {
      const response = await fetch('https://api.openai.com/v1/chat/completions', {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${OPENAI_API_KEY}`,
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({
          model: 'gpt-4',
          messages: [
            {
              role: 'system',
              content: `You are an experienced HR interviewer. Generate a relevant interview question based on the context. Focus on behavioral and situational questions. Keep questions professional and relevant to job interviews. If this is the first question, start with an introduction and an ice-breaker question. Return response in JSON format: { "question": "your question", "context": "why you're asking this" }`
            },
            {
              role: 'user',
              content: `Previous questions and answers: ${JSON.stringify({
                questions: hrQuestions,
                lastAnswer: transcript.length > 0 ? transcript[transcript.length - 1].text : null
              })}. Generate a new relevant interview question.`
            }
          ],
          temperature: 0.7
        })
      });

      if (!response.ok) throw new Error('Failed to generate question');
      
      const data = await response.json();
      let questionData;
      try {
        questionData = JSON.parse(data.choices[0].message.content);
      } catch (e) {
        // Fallback if parsing fails
        questionData = {
          question: data.choices[0].message.content,
          context: "Generated question"
        };
      }
      
      const newQuestion: HRQuestion = {
        question: questionData.question,
        context: questionData.context,
        timestamp: new Date().toLocaleTimeString()
      };
      
      setHrQuestions(prev => [...prev, newQuestion]);
      
      // Update session with the new question
      if (currentSession?.id) {
        setCurrentSession(prev => prev ? {
          ...prev,
          questions: [...(prev.questions || []), questionData.question]
        } : null);
      }
      
      // Text-to-speech for the question
      if ('speechSynthesis' in window) {
        window.speechSynthesis.cancel(); // Cancel any ongoing speech
        const speech = new SpeechSynthesisUtterance(questionData.question);
        speech.rate = 0.9;
        speech.pitch = 1;
        speech.volume = 1;
        window.speechSynthesis.speak(speech);
      }
      
    } catch (err) {
      console.error('Error generating HR question:', err);
    } finally {
      setIsGeneratingQuestion(false);
    }
  };

  // Start HR interview mode
  const startInterview = async () => {
    setIsInterviewMode(true);
    setHrQuestions([]);
    setTranscript([]); // Clear previous transcript
    await generateHRQuestion();
    
    // Remove the interval-based question generation
    if (interviewTimeoutRef.current) {
      clearInterval(interviewTimeoutRef.current);
      interviewTimeoutRef.current = null;
    }
  };

  // Stop HR interview mode
  const stopInterview = () => {
    setIsInterviewMode(false);
    if (interviewTimeoutRef.current) {
      clearInterval(interviewTimeoutRef.current);
      interviewTimeoutRef.current = null;
    }
    window.speechSynthesis.cancel(); // Cancel any ongoing speech
  };

  // Real-time feedback processing
  const processRealTimeFeedback = async (text: string) => {
    try {
      const response = await fetch('https://api.openai.com/v1/chat/completions', {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${OPENAI_API_KEY}`,
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({
          model: 'gpt-4',
          messages: [
            {
              role: 'system',
              content: `You are a language expert providing real-time feedback. Analyze the text for grammar, pronunciation hints, and fluency. Return feedback in JSON format: { "feedback": [{ "type": "grammar"|"pronunciation"|"fluency"|"vocabulary", "message": "feedback message", "severity": "info"|"warning"|"error" }] }`
            },
            {
              role: 'user',
              content: `Analyze this speech text for feedback: "${text}"`
            }
          ],
          temperature: 0.3
        })
      });

      if (!response.ok) throw new Error('Failed to get feedback');
      
      const data = await response.json();
      const feedbackData = JSON.parse(data.choices[0].message.content);
      
      const newFeedback: RealTimeFeedback[] = feedbackData.feedback.map((f: any) => ({
        ...f,
        timestamp: new Date().toLocaleTimeString()
      }));
      
      setRealTimeFeedback(prev => [...prev, ...newFeedback]);
      
    } catch (err) {
      console.error('Error processing real-time feedback:', err);
    }
  };

  // Remove the automatic question generation from transcript effect
  useEffect(() => {
    if (transcript.length > 0) {
      const lastTranscript = transcript[transcript.length - 1];
      processRealTimeFeedback(lastTranscript.text);
    }
  }, [transcript]);

  // Add Next Question handler
  const handleNextQuestion = async () => {
    if (!isInterviewMode) return;
    await generateHRQuestion();
  };

  // Cleanup on unmount
  useEffect(() => {
    return () => {
      if (interviewTimeoutRef.current) {
        clearInterval(interviewTimeoutRef.current);
      }
      window.speechSynthesis.cancel();
    };
  }, []);

  // End the practice session and save feedback
  const handleEndSession = async () => {
    if (!currentSession?.id || isSavingSession) return;
    
    setIsSavingSession(true);
    try {
      // Prepare feedback data
      const allText = transcript.map(t => t.text).join(' ');
      
      const feedbackData: Feedback = {
        sessionId: currentSession.id,
        transcript: allText,
        analysis: analysis ? JSON.stringify(analysis) : undefined,
        grammar: analysis ? 90 : undefined, // Example score, could be calculated from analysis
        pronunciation: 85,
        fluency: 80,
        timestamp: new Date(),
        score: 85, // Overall score
        corrections: aiTranscriptSuggestions.map(s => `${s.original} → ${s.suggestion}`),
        feedback: analysis?.overall_feedback || 'Session completed successfully'
      };
      
      // End the session in the backend
      await endSession(currentSession.id, feedbackData);
      
      // Update local session state
      setCurrentSession(prev => prev ? {
        ...prev,
        status: 'completed',
        endTime: new Date(),
        feedback: feedbackData
      } : null);
      
      console.log('Practice session ended and saved successfully');
      
      // Redirect to the session detail page
      navigate(`/session/${currentSession.id}`);
      
    } catch (error) {
      console.error('Failed to end practice session:', error);
    } finally {
      setIsSavingSession(false);
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-50 via-blue-50 to-indigo-100 dark:from-gray-900 dark:via-purple-900 dark:to-blue-900">
      <Navigation />
      
      <div className="pt-20 px-4 pb-8">
        <div className="container mx-auto">
          {/* Session Header */}
          <motion.div
            initial={{ opacity: 0, y: -20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
            className="mb-6 flex flex-col md:flex-row justify-between items-start md:items-center"
          >
            <div>
              <h1 className="text-2xl md:text-3xl font-bold mb-2">{currentTopic}</h1>
              <div className="flex items-center space-x-4 text-sm text-muted-foreground">
                <Badge variant="outline" className="text-green-600 border-green-600">
                  ● Live Session
                </Badge>
                <span>Duration: {formatTime(sessionDuration - timeRemaining)}</span>
              </div>
            </div>
            <Button 
              variant="destructive" 
              size="lg"
              onClick={handleEndSession}
              className="mt-4 md:mt-0"
              disabled={isSavingSession || !currentSession}
            >
              <Phone className="w-5 h-5 mr-2" />
              {isSavingSession ? 'Saving...' : 'End Session'}
            </Button>
          </motion.div>

          <div className="grid lg:grid-cols-3 gap-6">
            {/* Video Call Interface */}
            <motion.div
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.8, delay: 0.2 }}
              className="lg:col-span-2 space-y-6"
            >
              {/* Video Area */}
              <Card className="bg-white/80 dark:bg-gray-800/80 backdrop-blur-sm border-0 shadow-lg">
                <CardContent className="p-0 relative">
                  <div className="aspect-video bg-gradient-to-br from-gray-900 to-gray-700 rounded-t-lg relative overflow-hidden">
                    {/* AI Avatar */}
                    <motion.div
                      className="absolute inset-0 flex items-center justify-center"
                      animate={{ 
                        scale: [1, 1.02, 1],
                      }}
                      transition={{ 
                        duration: 3,
                        repeat: Infinity,
                        ease: "easeInOut"
                      }}
                    >
                      <div className="w-32 h-32 bg-gradient-to-r from-purple-500 to-blue-500 rounded-full flex items-center justify-center shadow-2xl">
                        <motion.div
                          className="w-24 h-24 bg-white/20 rounded-full flex items-center justify-center backdrop-blur-sm"
                          animate={{ 
                            boxShadow: [
                              "0 0 30px rgba(139, 92, 246, 0.4)",
                              "0 0 50px rgba(59, 130, 246, 0.6)",
                              "0 0 30px rgba(139, 92, 246, 0.4)"
                            ]
                          }}
                          transition={{ duration: 2, repeat: Infinity }}
                        >
                          <MessageSquare className="w-12 h-12 text-white" />
                        </motion.div>
                      </div>
                    </motion.div>

                    {/* User Video (small) */}
                    <div className="absolute bottom-2 right-4 w-64 h-64  border-white/20 flex items-center justify-center">
                      {isVideoOn && user ? (
                        <AspectRatio ratio={4/3} className="w-full h-full">
                          <video
                            ref={videoRef}
                            autoPlay
                            muted
                            playsInline
                            className="w-full h-full object-cover rounded-lg"
                            style={{ background: '#222' }}
                          />
                        </AspectRatio>
                      ) : (
                        <VideoOff className="w-6 h-6 text-white/60" />
                      )}
                    </div>

                    {/* Session Info Overlay */}
                    <div className="absolute top-4 left-4 bg-black/40 backdrop-blur-sm text-white px-3 py-2 rounded-lg">
                      <div className="text-sm font-medium">AI Conversation Partner</div>
                      <div className="text-xs opacity-80">Speaking fluency practice</div>
                    </div>

                    {/* Audio Visualization */}
                    <div className="absolute bottom-4 left-4 flex space-x-1">
                      {[...Array(5)].map((_, i) => (
                        <motion.div
                          key={i}
                          className="w-1 bg-green-400 rounded-full"
                          animate={{
                            height: [4, Math.random() * 20 + 4, 4],
                          }}
                          transition={{
                            duration: 0.5,
                            repeat: Infinity,
                            delay: i * 0.1,
                          }}
                        />
                      ))}
                    </div>
                  </div>

                  {/* Control Bar */}
                  <div className="p-4 bg-gray-900 text-white rounded-b-lg">
                    <div className="flex items-center justify-center space-x-4">
                      <Button
                        variant={isMicOn ? "default" : "destructive"}
                        size="icon"
                        onClick={() => setIsMicOn(!isMicOn)}
                        className="rounded-full"
                      >
                        {isMicOn ? <Mic className="w-5 h-5" /> : <MicOff className="w-5 h-5" />}
                      </Button>

                      <Button
                        variant={isVideoOn ? "default" : "destructive"}
                        size="icon"
                        onClick={() => setIsVideoOn(!isVideoOn)}
                        className="rounded-full"
                      >
                        {isVideoOn ? <Video className="w-5 h-5" /> : <VideoOff className="w-5 h-5" />}
                      </Button>

                      <Button
                        variant={isAudioOn ? "default" : "destructive"}
                        size="icon"
                        onClick={() => setIsAudioOn(!isAudioOn)}
                        className="rounded-full"
                      >
                        {isAudioOn ? <Volume2 className="w-5 h-5" /> : <VolumeX className="w-5 h-5" />}
                      </Button>

                      <Button
                        variant="outline"
                        size="icon"
                        className="rounded-full text-black"
                      >
                        <Settings className="w-5 h-5" />
                      </Button>

                      <Button
                        variant="outline"
                        size="icon"
                        className="rounded-full text-black"
                        onClick={() => window.location.reload()}
                      >
                        <RotateCcw className="w-5 h-5" />
                      </Button>
                    </div>
                  </div>
                </CardContent>
              </Card>

              {/* Real-time Transcript */}
              <Card className="bg-white/80 dark:bg-gray-800/80 backdrop-blur-sm border-0 shadow-lg">
                <CardContent className="p-6">
                  <h3 className="text-lg font-semibold mb-4 flex items-center">
                    <MessageSquare className="w-5 h-5 mr-2 text-primary" />
                    Live Transcript
                  </h3>
                  {!user && (
                    <div className="text-sm text-red-500">Please log in to use live video and transcript features.</div>
                  )}
                  <div className="space-y-3 max-h-64 overflow-y-auto">
                    {isTranscribing && (
                      <div className="text-sm text-blue-500 animate-pulse flex items-center">
                        <div className="w-2 h-2 bg-blue-500 rounded-full animate-bounce mr-2"></div>
                        Processing speech with Groq Whisper AI...
                      </div>
                    )}
                    {transcript.length === 0 && user && !isTranscribing && (
                      <div className="text-sm text-muted-foreground">Start speaking to see your transcript here.</div>
                    )}
                    {transcript.map((message, index) => (
                      <motion.div
                        key={index}
                        initial={{ opacity: 0, y: 10 }}
                        animate={{ opacity: 1, y: 0 }}
                        transition={{ duration: 0.3, delay: index * 0.1 }}
                        className={`flex ${message.speaker === (user?.name || 'You') ? 'justify-end' : 'justify-start'}`}
                      >
                        <div className={`max-w-[80%] p-3 rounded-lg ${
                          message.speaker === (user?.name || 'You')
                            ? 'bg-primary text-primary-foreground'
                            : 'bg-muted'
                        }`}>
                          <div className="flex items-center mb-1">
                            <span className="text-xs font-medium opacity-80">
                              {message.speaker}
                            </span>
                            <span className="text-xs opacity-60 ml-2">
                              {message.timestamp}
                            </span>
                          </div>
                          <p className="text-sm">{message.text}</p>
                        </div>
                      </motion.div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            </motion.div>

            

            {/* Feedback Panel */}
            <motion.div
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.8, delay: 0.4 }}
              className="space-y-6"
            >
              <Card className="bg-white/80 dark:bg-gray-800/80 backdrop-blur-sm border-0 shadow-lg">
                <CardContent className="p-6">
                  <div className="flex items-center justify-between mb-4">
                    <h3 className="text-lg font-semibold flex items-center">
                      <UserPlus className="w-5 h-5 mr-2 text-primary" />
                      HR Interview Practice
                    </h3>
                    {!isInterviewMode ? (
                      <Button
                        onClick={startInterview}
                        disabled={!isMicOn || !isCallActive}
                        className="bg-gradient-to-r from-green-500 to-blue-500 hover:from-green-600 hover:to-blue-600"
                      >
                        Start Interview
                      </Button>
                    ) : (
                      <div className="flex gap-2" style={{display:'flex'}}>
                        <Button
                          onClick={handleNextQuestion}
                          disabled={isGeneratingQuestion}
                          className="bg-gradient-to-r from-blue-500 to-purple-500 hover:from-blue-600 hover:to-purple-600"
                        >
                          {isGeneratingQuestion ? (
                            <>
                              <div className="w-2 h-2 border-2 border-white border-t-transparent rounded-full animate-spin mr-2"></div>
                              Generating...
                            </>
                          ) : (
                            'Next Question'
                          )}
                        </Button>
                        <Button
                          onClick={stopInterview}
                          className="bg-gradient-to-r from-red-500 to-pink-500 hover:from-red-600 hover:to-pink-600"
                        >
                          <StopCircle className="w-4 h-4 mr-2" />
                          End Interview
                        </Button>
                      </div>
                    )}
                  </div>

                  {isInterviewMode && (
                    <div className="space-y-4">
                      {/* Current Question */}
                      {hrQuestions.length > 0 && (
                        <div className="p-4 rounded-lg bg-gradient-to-r from-purple-50 to-blue-50 dark:from-purple-900/40 dark:to-blue-900/40 border border-purple-200 dark:border-purple-800">
                          <div className="text-sm font-medium text-purple-800 dark:text-purple-200 mb-2">
                            Current Question:
                          </div>
                          <div className="text-lg font-medium text-purple-900 dark:text-purple-100">
                            {hrQuestions[hrQuestions.length - 1].question}
                          </div>
                          {hrQuestions[hrQuestions.length - 1].context && (
                            <div className="mt-2 text-xs text-purple-700 dark:text-purple-300 italic">
                              Context: {hrQuestions[hrQuestions.length - 1].context}
                            </div>
                          )}
                        </div>
                      )}



                      {/* Question History */}
                      <div className="mt-4">
                        <div className="text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                          Previous Questions:
                        </div>
                        <div className="space-y-2">
                          {hrQuestions.slice(0, -1).reverse().map((q, idx) => (
                            <div
                              key={idx}
                              className="p-3 rounded-lg bg-gray-50 dark:bg-gray-900 border border-gray-200 dark:border-gray-700"
                            >
                              <div className="text-sm text-gray-900 dark:text-gray-100">
                                {q.question}
                              </div>
                              <div className="text-xs text-gray-500 dark:text-gray-400 mt-1">
                                {q.timestamp}
                              </div>
                            </div>
                          ))}
                        </div>
                      </div>
                    </div>
                  )}
                </CardContent>
              </Card>

              {/* Real-time Feedback */}
              <Card className="bg-white/80 dark:bg-gray-800/80 backdrop-blur-sm border-0 shadow-lg">
                <CardContent className="p-6">
                  <h3 className="text-lg font-semibold mb-3 flex items-center">
                    <AlertCircle className="w-5 h-5 mr-2 text-primary" />
                    Real-time Feedback
                  </h3>
                  
                  <div className="space-y-2">
                    {realTimeFeedback.slice(-5).reverse().map((feedback, idx) => (
                      <motion.div
                        key={idx}
                        initial={{ opacity: 0, y: 10 }}
                        animate={{ opacity: 1, y: 0 }}
                        transition={{ duration: 0.3 }}
                        className={`p-3 rounded-lg ${
                          feedback.severity === 'error'
                            ? 'bg-red-50 dark:bg-red-900/20 border-red-200 dark:border-red-800'
                            : feedback.severity === 'warning'
                            ? 'bg-yellow-50 dark:bg-yellow-900/20 border-yellow-200 dark:border-yellow-800'
                            : 'bg-blue-50 dark:bg-blue-900/20 border-blue-200 dark:border-blue-800'
                        } border`}
                      >
                        <div className="flex items-start">
                          <span className={`text-xs font-medium px-2 py-0.5 rounded ${
                            feedback.type === 'grammar'
                              ? 'bg-purple-100 text-purple-800 dark:bg-purple-900 dark:text-purple-200'
                              : feedback.type === 'pronunciation'
                              ? 'bg-blue-100 text-blue-800 dark:bg-blue-900 dark:text-blue-200'
                              : feedback.type === 'fluency'
                              ? 'bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-200'
                              : 'bg-orange-100 text-orange-800 dark:bg-orange-900 dark:text-orange-200'
                          }`}>
                            {feedback.type}
                          </span>
                          <span className="text-xs text-gray-500 dark:text-gray-400 ml-2">
                            {feedback.timestamp}
                          </span>
                        </div>
                        <div className="mt-1 text-sm">
                          {feedback.message}
                        </div>
                      </motion.div>
                    ))}
                    
                    {realTimeFeedback.length === 0 && (
                      <div className="text-center text-gray-500 dark:text-gray-400 p-4">
                        Start speaking to get real-time feedback on your language skills.
                      </div>
                    )}
                  </div>
                </CardContent>
              </Card>

              

              {/* AI Analysis */}
              <Card className="bg-white/80 dark:bg-gray-800/80 backdrop-blur-sm border-0 shadow-lg">
                <CardContent className="p-6">
                  <div className="flex items-center justify-between mb-4">
                    <h3 className="text-lg font-semibold flex items-center">
                      <AlertCircle className="w-5 h-5 mr-2 text-primary" />
                      Grammar Analysis
                    </h3>
                    <Button
                      onClick={handleAnalyse}
                      disabled={isAnalysing || transcript.length === 0}
                      className="bg-gradient-to-r from-purple-500 to-blue-500 hover:from-purple-600 hover:to-blue-600"
                    >
                      {isAnalysing ? (
                        <>
                          <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin mr-2"></div>
                          Analyzing...
                        </>
                      ) : (
                        'Analyze with AI'
                      )}
                    </Button>
                  </div>
                  
                  {analysisError && (
                    <div className="text-sm text-red-500 mb-4 p-3 bg-red-50 dark:bg-red-900/20 rounded-lg border border-red-200 dark:border-red-800">
                      {analysisError}
                    </div>
                  )}
                  
                  {analysis && (
                    <div className="space-y-4">
                      {/* Word-by-word analysis */}
                      <div className="p-4 rounded-lg bg-gray-50 dark:bg-gray-900 border border-gray-200 dark:border-gray-700">
                        <div className="font-semibold mb-2 flex items-center">
                          <CheckCircle className="w-4 h-4 mr-2 text-green-500" />
                          Word Analysis:
                        </div>
                        <div className="flex flex-wrap gap-1 mb-3">
                          {analysis.words?.map((item: any, idx: number) => (
                            <span
                              key={idx}
                              className={`px-2 py-1 rounded text-xs ${
                                item.correct
                                  ? 'bg-green-100 text-green-800 dark:bg-green-800 dark:text-green-100'
                                  : 'bg-red-100 text-red-800 dark:bg-red-800 dark:text-red-100 line-through'
                              }`}
                              title={item.explanation || ''}
                            >
                              {item.word}
                              {!item.correct && item.correction && (
                                <span className="ml-1 no-underline font-semibold">→ {item.correction}</span>
                              )}
                            </span>
                          ))}
                        </div>
                        <div className="text-xs text-muted-foreground">
                          Green = correct, Red with strikethrough = needs correction
                        </div>
                      </div>

                      {/* Overall feedback */}
                      {analysis.overall_feedback && (
                        <div className="p-3 rounded-lg bg-blue-50 dark:bg-blue-900/20 border border-blue-200 dark:border-blue-800">
                          <div className="text-sm font-medium text-blue-800 dark:text-blue-200 mb-1">
                            Overall Assessment:
                          </div>
                          <div className="text-sm text-blue-700 dark:text-blue-300">
                            {analysis.overall_feedback}
                          </div>
                        </div>
                      )}
                    </div>
                  )}
                </CardContent>
              </Card>

              {/* AI Suggestions */}
              <Card className="bg-white/80 dark:bg-gray-800/80 backdrop-blur-sm border-0 shadow-lg">
                <CardContent className="p-6">
                  <h3 className="text-lg font-semibold mb-1 flex items-center">
                    <Lightbulb className="w-5 h-5 mr-2 text-primary" />
                    AI Suggestions
                  </h3>
                  <div className="text-xs text-muted-foreground mb-4">
                    Modernize your language and improve clarity with these AI-powered tips:
                  </div>
                  
                  {aiTranscriptSuggestions.length > 0 ? (
                    <div className="space-y-3">
                      {aiTranscriptSuggestions.map((s, idx) => (
                        <motion.div
                          key={idx}
                          initial={{ opacity: 0, x: 10 }}
                          animate={{ opacity: 1, x: 0 }}
                          transition={{ duration: 0.3, delay: idx * 0.1 }}
                          className="p-3 rounded-lg bg-gradient-to-r from-blue-50 to-green-100 dark:from-blue-900/40 dark:to-green-900/40 border border-blue-200 dark:border-green-800"
                        >
                          <div className="mb-1">
                            <span className="font-semibold text-blue-700 dark:text-blue-200">Instead of:</span>
                            <span className="ml-2 bg-blue-100 dark:bg-blue-800 px-1.5 py-0.5 rounded text-blue-900 dark:text-blue-100 font-mono text-xs">
                              "{s.original}"
                            </span>
                          </div>
                          <div className="mb-1">
                            <span className="font-semibold text-green-700 dark:text-green-200">Try:</span>
                            <span className="ml-2 bg-green-100 dark:bg-green-800 px-1.5 py-0.5 rounded text-green-900 dark:text-green-100 font-mono text-xs">
                              "{s.suggestion}"
                            </span>
                          </div>
                          <div className="text-xs text-blue-700 dark:text-blue-200">
                            💡 {s.tip}
                          </div>
                        </motion.div>
                      ))}
                    </div>
                  ) : (
                    <div className="text-sm text-muted-foreground p-4 text-center border-2 border-dashed border-gray-300 dark:border-gray-600 rounded-lg">
                      Speak something and click "Analyze with AI" to get personalized suggestions!
                    </div>
                  )}
                </CardContent>
              </Card>
            </motion.div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Practice;
