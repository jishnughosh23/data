import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import Navigation from '@/components/Navigation';
import { 
  BarChart3, 
  TrendingUp, 
  Calendar, 
  Award, 
  Clock,
  Target,
  Mic,
  MessageSquare,
  BookOpen,
  AlertCircle
} from 'lucide-react';
import { getUserSessions } from '@/apitest/sessionapi';
import { toast } from '@/components/ui/use-toast';
import { LineChart, Line, XAxis, YAxis, CartesianGrid, ResponsiveContainer, BarChart, Bar, PieChart, Pie, Cell } from 'recharts';
import { useNavigate } from 'react-router-dom';
import { apiService } from '@/apitest/userapi';

const Analytics = () => {
  const [timeFilter, setTimeFilter] = useState('week');
  const [sessions, setSessions] = useState([]);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState(null);
  const navigate = useNavigate();
  
  // Fetch user sessions
  useEffect(() => {
    const fetchSessions = async () => {
      try {
        setIsLoading(true);
        const sessionsData = await getUserSessions();
        setSessions(sessionsData);
        setError(null);
      } catch (err) {
        console.error('Error fetching sessions:', err);
        setError('Failed to load session data');
        toast({
          title: 'Error',
          description: 'Failed to load analytics data. Please try again later.',
          variant: 'destructive',
        });
      } finally {
        setIsLoading(false);
      }
    };

    fetchSessions();
  }, []);

  useEffect(() => {
    if (!apiService.isAuthenticated()) {
      navigate('/login');
    }
  }, [navigate]);

  // Process session data for analytics
  const processSessionData = () => {
    if (!sessions.length) return null;

    // Calculate skill averages from session feedback
    const skillTotals = { grammar: 0, pronunciation: 0, fluency: 0, vocabulary: 0 };
    const skillCounts = { grammar: 0, pronunciation: 0, fluency: 0, vocabulary: 0 };
    
    // Track sessions by day for weekly progress
    const dayMap = {
      0: 'Sun', 1: 'Mon', 2: 'Tue', 3: 'Wed', 4: 'Thu', 5: 'Fri', 6: 'Sat'
    };
    
    const dailyProgress = {};
    const monthlySessionCounts = {};
    
    // Initialize daily progress with empty values
    Object.values(dayMap).forEach(day => {
      dailyProgress[day] = { day, grammar: 0, pronunciation: 0, fluency: 0, vocabulary: 0, count: 0 };
    });

    // Process each session
    sessions.forEach(session => {
      if (session.status === 'completed' && session.feedback) {
        const { grammar, pronunciation, fluency } = session.feedback;
        const day = dayMap[new Date(session.endTime).getDay()];
        const month = new Date(session.endTime).toLocaleString('default', { month: 'short' });
        
        // Add to skill totals
        if (grammar) {
          skillTotals.grammar += grammar;
          skillCounts.grammar += 1;
          dailyProgress[day].grammar += grammar;
        }
        
        if (pronunciation) {
          skillTotals.pronunciation += pronunciation;
          skillCounts.pronunciation += 1;
          dailyProgress[day].pronunciation += pronunciation;
        }
        
        if (fluency) {
          skillTotals.fluency += fluency;
          skillCounts.fluency += 1;
          dailyProgress[day].fluency += fluency;
        }
        
        // Vocabulary is estimated based on other skills for now
        const vocabEstimate = ((grammar || 0) + (pronunciation || 0) + (fluency || 0)) / 3;
        if (vocabEstimate) {
          skillTotals.vocabulary += vocabEstimate;
          skillCounts.vocabulary += 1;
          dailyProgress[day].vocabulary += vocabEstimate;
        }
        
        dailyProgress[day].count += 1;
        
        // Track monthly sessions
        monthlySessionCounts[month] = (monthlySessionCounts[month] || 0) + 1;
      }
    });
    
    // Calculate averages for skill distribution
    const skillDistribution = Object.entries(skillTotals).map(([name, total]) => {
      const count = skillCounts[name];
      const value = count > 0 ? Math.round(total / count) : 0;
      const color = {
        grammar: '#8B5CF6',
        pronunciation: '#3B82F6',
        fluency: '#10B981',
        vocabulary: '#F59E0B'
      }[name];
      
      return { name: name.charAt(0).toUpperCase() + name.slice(1), value, color };
    });
    
    // Format daily progress for chart
    const progressData = Object.values(dailyProgress).map(day => {
      const result = { day: day.day };
      ['grammar', 'pronunciation', 'fluency', 'vocabulary'].forEach(skill => {
        result[skill] = day.count > 0 ? Math.round(day[skill] / day.count) : 0;
      });
      return result;
    });
    
    // Format monthly session data
    const sessionData = Object.entries(monthlySessionCounts).map(([month, sessions]) => {
      // Estimate hours based on average session length of 20 minutes
      const hours = Math.round(sessions * 20 / 60 * 10) / 10;
      return { month, sessions, hours };
    });
    
    // Calculate weekly stats
    const completedSessions = sessions.filter(s => s.status === 'completed');
    const totalSessions = completedSessions.length;
    
    // Calculate total practice time (assuming 20 min average if endTime-startTime not available)
    let totalMinutes = 0;
    completedSessions.forEach(session => {
      if (session.startTime && session.endTime) {
        const duration = new Date(session.endTime) - new Date(session.startTime);
        totalMinutes += duration / (1000 * 60); // Convert ms to minutes
      } else {
        totalMinutes += 20; // Assume 20 minutes if times not available
      }
    });

    const totalHours = Math.round(totalMinutes / 60 * 10) / 10;
    
    // Calculate average score
    let totalScore = 0;
    let scoreCount = 0;
    completedSessions.forEach(session => {
      if (session.feedback && session.feedback.score) {
        totalScore += session.feedback.score;
        scoreCount += 1;
      }
    });
    
    const averageScore = scoreCount > 0 ? Math.round(totalScore / scoreCount) : 0;
    
    // Estimate improvement (comparing recent vs older sessions)
    let improvement = 0;
    if (completedSessions.length >= 4) {
      const sortedSessions = [...completedSessions].sort((a, b) => 
        new Date(b.endTime) - new Date(a.endTime)
      );
      
      const recentSessions = sortedSessions.slice(0, Math.ceil(sortedSessions.length / 2));
      const olderSessions = sortedSessions.slice(Math.ceil(sortedSessions.length / 2));
      
      let recentScoreTotal = 0, recentCount = 0;
      let olderScoreTotal = 0, olderCount = 0;
      
      recentSessions.forEach(session => {
        if (session.feedback && session.feedback.score) {
          recentScoreTotal += session.feedback.score;
          recentCount += 1;
        }
      });
      
      olderSessions.forEach(session => {
        if (session.feedback && session.feedback.score) {
          olderScoreTotal += session.feedback.score;
          olderCount += 1;
        }
      });
      
      const recentAvg = recentCount > 0 ? recentScoreTotal / recentCount : 0;
      const olderAvg = olderCount > 0 ? olderScoreTotal / olderCount : 0;
      
      if (olderAvg > 0) {
        improvement = Math.round((recentAvg - olderAvg) / olderAvg * 100);
      }
    }
    
    // Generate achievements based on real data
  const achievements = [
      { 
        title: '7-Day Streak', 
        description: 'Practiced 7 days in a row', 
        icon: '🔥', 
        achieved: false // Would need to implement streak calculation
      },
      { 
        title: 'Grammar Master', 
        description: '90% accuracy in grammar', 
        icon: '📚', 
        achieved: skillDistribution.find(s => s.name === 'Grammar')?.value >= 90 || false 
      },
      { 
        title: 'Pronunciation Pro', 
        description: '90% pronunciation score', 
        icon: '🎯', 
        achieved: skillDistribution.find(s => s.name === 'Pronunciation')?.value >= 90 || false
      },
      { 
        title: 'Conversation Expert', 
        description: '10+ practice sessions', 
        icon: '💬', 
        achieved: totalSessions >= 10
      },
    ];
    
    return {
      progressData,
      sessionData,
      skillDistribution,
      achievements,
      weeklyStats: {
        totalSessions,
        totalHours,
        averageScore,
        improvement
      }
    };
  };
  
  const analyticsData = processSessionData() || {
    progressData: [
      { day: 'Mon', grammar: 0, pronunciation: 0, fluency: 0, vocabulary: 0 },
      { day: 'Tue', grammar: 0, pronunciation: 0, fluency: 0, vocabulary: 0 },
      { day: 'Wed', grammar: 0, pronunciation: 0, fluency: 0, vocabulary: 0 },
      { day: 'Thu', grammar: 0, pronunciation: 0, fluency: 0, vocabulary: 0 },
      { day: 'Fri', grammar: 0, pronunciation: 0, fluency: 0, vocabulary: 0 },
      { day: 'Sat', grammar: 0, pronunciation: 0, fluency: 0, vocabulary: 0 },
      { day: 'Sun', grammar: 0, pronunciation: 0, fluency: 0, vocabulary: 0 }
    ],
    sessionData: [],
    skillDistribution: [
      { name: 'Grammar', value: 0, color: '#8B5CF6' },
      { name: 'Pronunciation', value: 0, color: '#3B82F6' },
      { name: 'Fluency', value: 0, color: '#10B981' },
      { name: 'Vocabulary', value: 0, color: '#F59E0B' }
    ],
    achievements: [
      { title: '7-Day Streak', description: 'Practiced 7 days in a row', icon: '🔥', achieved: false },
      { title: 'Grammar Master', description: '90% accuracy in grammar', icon: '📚', achieved: false },
    { title: 'Pronunciation Pro', description: '90% pronunciation score', icon: '🎯', achieved: false },
      { title: 'Conversation Expert', description: '10+ practice sessions', icon: '💬', achieved: false },
    ],
    weeklyStats: {
      totalSessions: 0,
      totalHours: 0,
      averageScore: 0,
      improvement: 0
    }
  };
  
  const { progressData, sessionData, skillDistribution, achievements, weeklyStats } = analyticsData;

  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-50 via-blue-50 to-indigo-100 dark:from-gray-900 dark:via-purple-900 dark:to-blue-900">
      <Navigation />
      
      <div className="pt-20 px-4 pb-8">
        <div className="container mx-auto">
          {/* Header */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
            className="mb-8"
          >
            <div className="flex flex-col md:flex-row justify-between items-start md:items-center mb-6">
              <div>
                <h1 className="text-3xl md:text-4xl font-bold mb-2 flex items-center">
                  <BarChart3 className="w-8 h-8 mr-3 text-primary" />
                  Progress Analytics
                </h1>
                <p className="text-muted-foreground text-lg">
                  Track your improvement and achievements
                </p>
              </div>
              <div className="flex space-x-2 mt-4 md:mt-0">
                <Button 
                  variant={timeFilter === 'week' ? 'default' : 'outline'}
                  onClick={() => setTimeFilter('week')}
                >
                  Week
                </Button>
                <Button 
                  variant={timeFilter === 'month' ? 'default' : 'outline'}
                  onClick={() => setTimeFilter('month')}
                >
                  Month
                </Button>
              </div>
            </div>

            {/* Loading State */}
            {isLoading && (
              <div className="flex justify-center items-center py-8">
                <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary"></div>
              </div>
            )}
            
            {/* Error State */}
            {error && (
              <div className="bg-red-50 dark:bg-red-900/20 border border-red-200 dark:border-red-800 rounded-lg p-4 mb-6">
                <div className="flex items-center">
                  <AlertCircle className="h-5 w-5 text-red-600 dark:text-red-400 mr-2" />
                  <p className="text-red-600 dark:text-red-400">{error}</p>
                </div>
              </div>
            )}

            {/* Quick Stats */}
            {!isLoading && !error && (
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
              {[
                  { label: 'Sessions', value: weeklyStats.totalSessions, icon: MessageSquare, change: weeklyStats.totalSessions > 0 ? '+' : '' },
                  { label: 'Hours', value: `${weeklyStats.totalHours}h`, icon: Clock, change: weeklyStats.totalHours > 0 ? '+' : '' },
                  { label: 'Avg Score', value: `${weeklyStats.averageScore}%`, icon: Target, change: weeklyStats.averageScore > 0 ? '+' : '' },
                  { label: 'Improvement', value: `${weeklyStats.improvement > 0 ? '+' : ''}${weeklyStats.improvement}%`, icon: TrendingUp, change: weeklyStats.improvement > 0 ? '+' : '' }
                ].map((stat, index) => {
                  const Icon = stat.icon;
                  return (
                <motion.div
                  key={index}
                  initial={{ opacity: 0, scale: 0.9 }}
                  animate={{ opacity: 1, scale: 1 }}
                  transition={{ duration: 0.5, delay: index * 0.1 }}
                >
                  <Card className="bg-white/80 dark:bg-gray-800/80 backdrop-blur-sm border-0 shadow-lg">
                    <CardContent className="p-4">
                      <div className="flex items-center justify-between">
                        <div>
                          <p className="text-sm text-muted-foreground">{stat.label}</p>
                          <p className="text-2xl font-bold">{stat.value}</p>
                          <p className="text-xs text-green-600">{stat.change}</p>
                        </div>
                            <Icon className="w-8 h-8 text-primary" />
                      </div>
                    </CardContent>
                  </Card>
                </motion.div>
                  );
                })}
            </div>
            )}
          </motion.div>

          {/* Charts Section */}
          <Tabs defaultValue="skills" className="space-y-6">
            <TabsList className="grid w-full grid-cols-4">
              <TabsTrigger value="skills">Skills Progress</TabsTrigger>
              <TabsTrigger value="sessions">Sessions</TabsTrigger>
              <TabsTrigger value="distribution">Skills Distribution</TabsTrigger>
              <TabsTrigger value="achievements">Achievements</TabsTrigger>
            </TabsList>

            <TabsContent value="skills">
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.8 }}
              >
                <Card className="bg-white/80 dark:bg-gray-800/80 backdrop-blur-sm border-0 shadow-lg">
                  <CardHeader>
                    <CardTitle>Weekly Skills Progress</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <ResponsiveContainer width="100%" height={400}>
                      <LineChart data={progressData}>
                        <CartesianGrid strokeDasharray="3 3" opacity={0.3} />
                        <XAxis dataKey="day" />
                        <YAxis domain={[70, 100]} />
                        <Line 
                          type="monotone" 
                          dataKey="grammar" 
                          stroke="#8B5CF6" 
                          strokeWidth={3}
                          dot={{ r: 6 }}
                        />
                        <Line 
                          type="monotone" 
                          dataKey="pronunciation" 
                          stroke="#3B82F6" 
                          strokeWidth={3}
                          dot={{ r: 6 }}
                        />
                        <Line 
                          type="monotone" 
                          dataKey="fluency" 
                          stroke="#10B981" 
                          strokeWidth={3}
                          dot={{ r: 6 }}
                        />
                        <Line 
                          type="monotone" 
                          dataKey="vocabulary" 
                          stroke="#F59E0B" 
                          strokeWidth={3}
                          dot={{ r: 6 }}
                        />
                      </LineChart>
                    </ResponsiveContainer>
                    <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mt-6">
                      {[
                        { name: 'Grammar', color: '#8B5CF6' },
                        { name: 'Pronunciation', color: '#3B82F6' },
                        { name: 'Fluency', color: '#10B981' },
                        { name: 'Vocabulary', color: '#F59E0B' }
                      ].map((skill, index) => (
                        <div key={index} className="flex items-center">
                          <div 
                            className="w-4 h-4 rounded-full mr-2"
                            style={{ backgroundColor: skill.color }}
                          />
                          <span className="text-sm">{skill.name}</span>
                        </div>
                      ))}
                    </div>
                  </CardContent>
                </Card>
              </motion.div>
            </TabsContent>

            <TabsContent value="sessions">
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.8 }}
              >
                <Card className="bg-white/80 dark:bg-gray-800/80 backdrop-blur-sm border-0 shadow-lg">
                  <CardHeader>
                    <CardTitle>Practice Sessions Over Time</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <ResponsiveContainer width="100%" height={400}>
                      <BarChart data={sessionData}>
                        <CartesianGrid strokeDasharray="3 3" opacity={0.3} />
                        <XAxis dataKey="month" />
                        <YAxis />
                        <Bar dataKey="sessions" fill="#8B5CF6" radius={[4, 4, 0, 0]} />
                      </BarChart>
                    </ResponsiveContainer>
                  </CardContent>
                </Card>
              </motion.div>
            </TabsContent>

            <TabsContent value="distribution">
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.8 }}
              >
                <Card className="bg-white/80 dark:bg-gray-800/80 backdrop-blur-sm border-0 shadow-lg">
                  <CardHeader>
                    <CardTitle>Current Skills Distribution</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="grid md:grid-cols-2 gap-8 items-center">
                      <ResponsiveContainer width="100%" height={300}>
                        <PieChart>
                          <Pie
                            data={skillDistribution}
                            cx="50%"
                            cy="50%"
                            outerRadius={100}
                            dataKey="value"
                            label={({ name, value }) => `${name}: ${value}%`}
                          >
                            {skillDistribution.map((entry, index) => (
                              <Cell key={`cell-${index}`} fill={entry.color} />
                            ))}
                          </Pie>
                        </PieChart>
                      </ResponsiveContainer>
                      <div className="space-y-4">
                        {skillDistribution.map((skill, index) => (
                          <div key={index} className="space-y-2">
                            <div className="flex justify-between items-center">
                              <span className="font-medium">{skill.name}</span>
                              <span className="font-bold">{skill.value}%</span>
                            </div>
                            <div className="w-full bg-gray-200 dark:bg-gray-700 rounded-full h-2">
                              <motion.div
                                className="h-2 rounded-full"
                                style={{ backgroundColor: skill.color }}
                                initial={{ width: 0 }}
                                animate={{ width: `${skill.value}%` }}
                                transition={{ duration: 1, delay: index * 0.2 }}
                              />
                            </div>
                          </div>
                        ))}
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </motion.div>
            </TabsContent>

            <TabsContent value="achievements">
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.8 }}
                className="grid md:grid-cols-2 gap-6"
              >
                {achievements.map((achievement, index) => (
                  <motion.div
                    key={index}
                    initial={{ opacity: 0, scale: 0.9 }}
                    animate={{ opacity: 1, scale: 1 }}
                    transition={{ duration: 0.5, delay: index * 0.1 }}
                  >
                    <Card className={`bg-white/80 dark:bg-gray-800/80 backdrop-blur-sm border-0 shadow-lg ${
                      achievement.achieved ? 'ring-2 ring-green-500' : ''
                    }`}>
                      <CardContent className="p-6">
                        <div className="flex items-center space-x-4">
                          <div className="text-4xl">{achievement.icon}</div>
                          <div className="flex-1">
                            <h3 className="font-semibold text-lg flex items-center">
                              {achievement.title}
                              {achievement.achieved && (
                                <Award className="w-5 h-5 ml-2 text-green-500" />
                              )}
                            </h3>
                            <p className="text-muted-foreground text-sm">
                              {achievement.description}
                            </p>
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  </motion.div>
                ))}
              </motion.div>
            </TabsContent>
          </Tabs>
        </div>
      </div>
    </div>
  );
};

export default Analytics;
