import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Progress } from '@/components/ui/progress';
import { Link, useNavigate } from 'react-router-dom';
import { Badge } from '@/components/ui/badge';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { 
  MessageSquare, 
  Video, 
  CheckCircle, 
  BookOpen, 
  Trophy, 
  Clock,
  Play,
  BarChart3,
  Globe,
  Mic,
  Calendar,
  Award
} from 'lucide-react';
import { apiService } from '@/apitest/userapi';
import { getUserSessions, PracticeSession } from '@/apitest/sessionapi';
import { Popover, PopoverContent, PopoverTrigger } from '@/components/ui/popover';

const Dashboard = () => {
  const [user, setUser] = useState(null);
  const [sessions, setSessions] = useState<PracticeSession[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const navigate = useNavigate();

  useEffect(() => {
    if (!apiService.isAuthenticated()) {
      navigate('/login');
    }
  }, [navigate]);

  useEffect(() => {
    const currentUser = apiService.getCurrentUser();
    setUser(currentUser);
  }, []);

  useEffect(() => {
    const fetchSessions = async () => {
      if (!user) return;
      
      try {
        setIsLoading(true);
        const userSessions = await getUserSessions();
        console.log('Fetched sessions:', userSessions);
        setSessions(userSessions);
        setError(null); // Clear any previous errors on successful fetch
      } catch (err) {
        console.error('Error fetching sessions:', err);
        setError('Failed to load your practice sessions. Please try again later.');
        // Provide mock data for development/testing when API fails
        setSessions([
          {
            id: 'mock1',
            user_id: user?.id || 'user1',
            topic_id: 'interview-practice',
            start_time: new Date(Date.now() - 3600000),
            end_time: new Date(),
            status: 'completed',
            created_at: new Date(Date.now() - 3600000),
            updated_at: new Date(),
            feedback: { score: 92 }
          },
          {
            id: 'mock2',
            user_id: user?.id || 'user1',
            topic_id: 'daily-conversation',
            start_time: new Date(Date.now() - 86400000),
            end_time: new Date(Date.now() - 82800000),
            status: 'completed',
            created_at: new Date(Date.now() - 86400000),
            updated_at: new Date(Date.now() - 82800000),
            feedback: { score: 88 }
          },
          {
            id: 'mock3',
            user_id: user?.id || 'user1',
            topic_id: 'pronunciation',
            start_time: new Date(Date.now() - 172800000),
            end_time: new Date(Date.now() - 169200000),
            status: 'completed',
            created_at: new Date(Date.now() - 172800000),
            updated_at: new Date(Date.now() - 169200000),
            feedback: { score: 95 }
          }
        ]);
      } finally {
        setIsLoading(false);
      }
    };

    fetchSessions();
  }, [user]);

  function getFirstName(name: string) {
    if (!name) return '';
    return name.trim().split(' ')[0];
  }

  // Format date for display
  const formatDate = (dateString: string | Date) => {
    if (!dateString) return 'N/A';
    
    try {
      const date = new Date(dateString);
      
      if (isNaN(date.getTime())) {
        console.error('Invalid date format:', dateString);
        return 'N/A';
      }
      
      return date.toLocaleDateString('en-US', { 
        year: 'numeric', 
        month: 'short', 
        day: 'numeric',
        hour: '2-digit',
        minute: '2-digit'
      });
    } catch (error) {
      console.error('Error formatting date:', error);
      return 'N/A';
    }
  };

  // Calculate session duration
  const calculateDuration = (startTime: string | Date, endTime: string | Date) => {
    if (!startTime || !endTime) return 'N/A';
    
    try {
      const start = new Date(startTime);
      const end = new Date(endTime);
      
      if (isNaN(start.getTime()) || isNaN(end.getTime())) {
        console.error('Invalid date format:', { startTime, endTime });
        return 'N/A';
      }
      
      const durationMs = end.getTime() - start.getTime();
      
      if (durationMs < 0) {
        console.error('Negative duration:', { startTime, endTime, durationMs });
        return 'N/A';
      }
      
      const minutes = Math.floor(durationMs / (1000 * 60));
      const seconds = Math.floor((durationMs % (1000 * 60)) / 1000);
      
      return `${minutes}m ${seconds}s`;
    } catch (error) {
      console.error('Error calculating duration:', error);
      return 'N/A';
    }
  };
  
  const languages = [
    { name: 'English', flag: '🇺🇸', level: 'Advanced', progress: 85 },
    { name: 'Spanish', flag: '🇪🇸', level: 'Intermediate', progress: 60 },
    { name: 'French', flag: '🇫🇷', level: 'Beginner', progress: 25 },
    { name: 'German', flag: '🇩🇪', level: 'Beginner', progress: 15 },
  ];

  const practiceModules = [
    {
      title: 'Interview Prep',
      description: 'Practice common interview questions',
      icon: MessageSquare,
      color: 'from-blue-500 to-cyan-500',
      sessions: 12,
      link: '/practice'
    },
    {
      title: 'Communication Practice',
      description: 'Improve daily conversation skills',
      icon: Video,
      color: 'from-purple-500 to-pink-500',
      sessions: 8,
      link: '/practice'
    },
    {
      title: 'Grammar Check',
      description: 'Real-time grammar correction',
      icon: CheckCircle,
      color: 'from-green-500 to-emerald-500',
      sessions: 15,
      link: '/practice'
    },
    {
      title: 'Pronunciation',
      description: 'Perfect your accent and pronunciation',
      icon: Mic,
      color: 'from-orange-500 to-red-500',
      sessions: 10,
      link: '/practice'
    }
  ];

  const recentActivities = [
    { type: 'practice', title: 'Interview Practice Session', time: '2 hours ago', score: 92 },
    { type: 'lesson', title: 'Business Communication', time: '1 day ago', score: 88 },
    { type: 'practice', title: 'Pronunciation Exercise', time: '2 days ago', score: 95 },
  ];

  // Calculate user stats from sessions data
  const userStats = {
    totalSessions: sessions.length,
    hoursSpent: Math.round(sessions.reduce((total, session) => {
      if (session.startTime && session.endTime) {
        const start = new Date(session.startTime);
        const end = new Date(session.endTime);
        return total + (end.getTime() - start.getTime()) / (1000 * 60 * 60);
      }
      return total;
    }, 0) * 10) / 10, // Round to 1 decimal place
    averageScore: sessions.length > 0 
      ? Math.round(sessions.reduce((sum, session) => {
          return sum + (session.feedback?.score || 0);
        }, 0) / sessions.filter(s => s.feedback?.score).length) 
      : 0,
    streak: 7 // This would need a more complex calculation based on consecutive days
  };

  const [activeLanguageIndex, setActiveLanguageIndex] = React.useState<number | null>(null);

  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-50 via-blue-50 to-indigo-100 dark:from-gray-900 dark:via-purple-900 dark:to-blue-900">
      <div className="pt-20 px-4 pb-8">
        <div className="container mx-auto">
          {/* Welcome Section */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
            className="mb-8"
          >
            <div className="flex flex-col md:flex-row justify-between items-start md:items-center mb-6">
              <div>
                <h1 className="text-3xl md:text-4xl font-bold mb-2">
                  Welcome back, {getFirstName(user?.name)}! 👋
                </h1>
                <p className="text-muted-foreground text-lg">
                  Ready to continue your learning journey?
                </p>
              </div>
              <Link to="/practice">
                <Button size="lg" className="bg-gradient-to-r from-purple-600 to-blue-600 hover:from-purple-700 hover:to-blue-700 mt-4 md:mt-0">
                  <Play className="w-5 h-5 mr-2" />
                  Start Practice
                </Button>
              </Link>
            </div>

            {/* Progress Overview */}
            <Card className="bg-white/80 dark:bg-gray-800/80 backdrop-blur-sm border-0 shadow-lg">
              <CardContent className="p-6">
                <div className="grid grid-cols-2 md:grid-cols-4 gap-6">
                  <div className="text-center">
                    <div className="text-2xl font-bold text-primary">{userStats.totalSessions}</div>
                    <p className="text-sm text-muted-foreground">Total Sessions</p>
                  </div>
                  <div className="text-center">
                    <div className="text-2xl font-bold text-primary">{userStats.hoursSpent}h</div>
                    <p className="text-sm text-muted-foreground">Hours Practiced</p>
                  </div>
                  <div className="text-center">
                    <div className="text-2xl font-bold text-primary">{userStats.averageScore}%</div>
                    <p className="text-sm text-muted-foreground">Average Score</p>
                  </div>
                  <div className="text-center">
                    <div className="text-2xl font-bold text-primary">{userStats.streak} days</div>
                    <p className="text-sm text-muted-foreground">Current Streak</p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </motion.div>

          {/* Languages Section */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, delay: 0.2 }}
            className="mb-8"
          >
            <h2 className="text-2xl font-bold mb-6 flex items-center">
              <Globe className="w-6 h-6 mr-2 text-primary" />
              Your Languages
            </h2>
            
            <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
              {languages.map((language, index) => (
                <motion.div
                  key={index}
                  initial={{ opacity: 0, scale: 0.9 }}
                  animate={{ opacity: 1, scale: 1 }}
                  transition={{ duration: 0.5, delay: index * 0.1 }}
                  whileHover={{ y: -5 }}
                >
                  <Popover open={activeLanguageIndex === index} onOpenChange={(open) => setActiveLanguageIndex(open ? index : null)}>
                    <PopoverTrigger asChild>
                      <div onClick={() => setActiveLanguageIndex(index)}>
                        <Card className="bg-white/80 dark:bg-gray-800/80 backdrop-blur-sm border-0 shadow-lg hover:shadow-xl transition-all duration-300 cursor-pointer">
                          <CardContent className="p-6 text-center">
                            <div className="text-4xl mb-4">{language.flag}</div>
                            <h3 className="font-semibold text-lg mb-2">{language.name}</h3>
                            <p className="text-sm text-muted-foreground mb-4">{language.level}</p>
                            <Progress value={language.progress} className="mb-2" />
                            <p className="text-xs text-muted-foreground">{language.progress}% Complete</p>
                          </CardContent>
                        </Card>
                      </div>
                    </PopoverTrigger>
                    <PopoverContent align="center" className="w-56">
                      <div className="flex flex-col gap-2">
                        <Button variant="ghost" className="justify-start" onClick={() => { setActiveLanguageIndex(null); navigate('/practice', { state: { language: language.name, mode: 'basic' } }); }}>
                          Learn basic things for practice
                        </Button>
                        <Button variant="ghost" className="justify-start" onClick={() => { setActiveLanguageIndex(null); navigate('/game', { state: { language: language.name } }); }}>
                          Game-based learning
                        </Button>
                        <Button variant="ghost" className="justify-start" onClick={() => { setActiveLanguageIndex(null); /* handle advanced navigation here */ }}>
                          Advanced
                        </Button>
                      </div>
                    </PopoverContent>
                  </Popover>
                </motion.div>
              ))}
            </div>
          </motion.div>

          {/* Practice Modules */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, delay: 0.4 }}
            className="mb-8"
          >
            <h2 className="text-2xl font-bold mb-6 flex items-center">
              <BookOpen className="w-6 h-6 mr-2 text-primary" />
              Practice Modules
            </h2>
            
            <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
              {practiceModules.map((module, index) => (
                <motion.div
                  key={index}
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.5, delay: index * 0.1 }}
                  whileHover={{ scale: 1.05 }}
                >
                  <Link to={module.link}>
                    <Card className="h-full bg-white/80 dark:bg-gray-800/80 backdrop-blur-sm border-0 shadow-lg hover:shadow-xl transition-all duration-300 cursor-pointer">
                      <CardContent className="p-6">
                        <div className={`w-12 h-12 rounded-full bg-gradient-to-r ${module.color} flex items-center justify-center mb-4`}>
                          <module.icon className="w-6 h-6 text-white" />
                        </div>
                        <h3 className="font-semibold text-lg mb-2">{module.title}</h3>
                        <p className="text-sm text-muted-foreground mb-4">{module.description}</p>
                        <div className="flex items-center text-xs text-muted-foreground">
                          <Clock className="w-4 h-4 mr-1" />
                          {module.sessions} sessions completed
                        </div>
                      </CardContent>
                    </Card>
                  </Link>
                </motion.div>
              ))}
            </div>
          </motion.div>

          {/* Practice Session History */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, delay: 0.6 }}
            className="mb-8"
          >
            <h2 className="text-2xl font-bold mb-6 flex items-center">
              <Calendar className="w-6 h-6 mr-2 text-primary" />
              Practice Session History
            </h2>
            
            <Card className="bg-white/80 dark:bg-gray-800/80 backdrop-blur-sm border-0 shadow-lg">
              <CardContent className="p-6">
                {isLoading ? (
                  <div className="flex justify-center items-center p-8">
                    <div className="w-8 h-8 border-4 border-primary border-t-transparent rounded-full animate-spin"></div>
                  </div>
                ) : error ? (
                  <div className="text-center text-red-500 p-4">{error}</div>
                ) : sessions.length === 0 ? (
                  <div className="text-center text-muted-foreground p-8">
                    <MessageSquare className="h-12 w-12 mx-auto mb-4 opacity-20" />
                    <p>You haven't completed any practice sessions yet.</p>
                    <Button className="mt-4" onClick={() => navigate('/practice')}>
                      Start Practicing
                    </Button>
                  </div>
                ) : (
                  <div className="overflow-x-auto">
                    <Table>
                      <TableHeader>
                        <TableRow>
                          <TableHead>Date</TableHead>
                          <TableHead>Topic</TableHead>
                          <TableHead>Language</TableHead>
                          <TableHead>Duration</TableHead>
                          <TableHead>Status</TableHead>
                          <TableHead>Score</TableHead>
                          <TableHead>Actions</TableHead>
                        </TableRow>
                      </TableHeader>
                      <TableBody>
                        {sessions.slice(0, 5).map((session) => (
                          <TableRow key={session.id}>
                            <TableCell>{formatDate(session.start_time || '')}</TableCell>
                            <TableCell>{session.topic_id ? session.topic_id.toString() : 'N/A'}</TableCell>
                            <TableCell>Practice Session</TableCell>
                            <TableCell>
                              {calculateDuration(session.start_time || '', session.end_time || '')}
                            </TableCell>
                            <TableCell>
                              <Badge 
                                className={`${session.status === 'completed' 
                                  ? 'bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-100' 
                                  : session.status === 'active' 
                                  ? 'bg-blue-100 text-blue-800 dark:bg-blue-900 dark:text-blue-100' 
                                  : 'bg-gray-100 text-gray-800 dark:bg-gray-800 dark:text-gray-200'}`}
                              >
                                {session.status}
                              </Badge>
                            </TableCell>
                            <TableCell>
                              {session.feedback?.score || 'N/A'}
                            </TableCell>
                            <TableCell>
                              <Button 
                                variant="outline" 
                                size="sm"
                                onClick={() => navigate(`/session/${session.id}`)}
                              >
                                View Details
                              </Button>
                            </TableCell>
                          </TableRow>
                        ))}
                      </TableBody>
                    </Table>
                    {sessions.length > 5 && (
                      <div className="mt-4 text-center">
                        <Button variant="outline" onClick={() => navigate('/sessions')}>
                          View All Sessions ({sessions.length})
                        </Button>
                      </div>
                    )}
                  </div>
                )}
              </CardContent>
            </Card>
          </motion.div>

          {/* Recent Activity & Quick Actions */}
          <div className="grid lg:grid-cols-2 gap-8">
            {/* Recent Activity */}
            <motion.div
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.8, delay: 0.8 }}
            >
              <Card className="bg-white/80 dark:bg-gray-800/80 backdrop-blur-sm border-0 shadow-lg">
                <CardHeader>
                  <CardTitle className="flex items-center">
                    <BarChart3 className="w-5 h-5 mr-2 text-primary" />
                    Recent Activity
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    {recentActivities.map((activity, index) => (
                      <div key={index} className="flex items-center justify-between p-3 bg-background/50 rounded-lg">
                        <div>
                          <p className="font-medium">{activity.title}</p>
                          <p className="text-sm text-muted-foreground">{activity.time}</p>
                        </div>
                        <div className="text-right">
                          <div className="text-lg font-semibold text-primary">{activity.score}%</div>
                          <Trophy className="w-4 h-4 text-yellow-500 mx-auto" />
                        </div>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            </motion.div>

            {/* Quick Actions */}
            <motion.div
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.8, delay: 0.8 }}
            >
              <Card className="bg-white/80 dark:bg-gray-800/80 backdrop-blur-sm border-0 shadow-lg">
                <CardHeader>
                  <CardTitle>Quick Actions</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <Link to="/analytics">
                    <Button variant="outline" className="w-full justify-start">
                      <BarChart3 className="w-5 h-5 mr-3" />
                      View Progress Analytics
                    </Button>
                  </Link>
                  <Link to="/practice">
                    <Button variant="outline" className="w-full justify-start">
                      <Video className="w-5 h-5 mr-3" />
                      Start Video Practice
                    </Button>
                  </Link>
                  <Link to="/settings">
                    <Button variant="outline" className="w-full justify-start">
                      <Globe className="w-5 h-5 mr-3" />
                      Add New Language
                    </Button>
                  </Link>
                </CardContent>
              </Card>
            </motion.div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Dashboard;
