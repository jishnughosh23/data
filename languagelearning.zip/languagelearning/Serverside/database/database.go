package database

import (
	"context"
	"log"
	"os"
	"time"

	"go.mongodb.org/mongo-driver/mongo"
	"go.mongodb.org/mongo-driver/mongo/options"
)

var (
	Client   *mongo.Client
	Database *mongo.Database
	ctx      = context.Background()
)

func Init() {
	mongoURI := os.Getenv("MONGODB_URI")
	if mongoURI == "" {
		mongoURI = "mongodb://localhost:27017"
	}

	clientOptions := options.Client().ApplyURI(mongoURI)
	ctx, cancel := context.WithTimeout(context.Background(), 10*time.Second)
	defer cancel()

	var err error
	Client, err = mongo.Connect(ctx, clientOptions)
	if err != nil {
		log.Fatal(err)
	}

	// Ping the database
	err = Client.Ping(ctx, nil)
	if err != nil {
		log.Fatal(err)
	}

	Database = Client.Database("languagelearning")
	log.Println("Connected to MongoDB!")
}

func Close() {
	if Client != nil {
		ctx, cancel := context.WithTimeout(context.Background(), 10*time.Second)
		defer cancel()
		if err := Client.Disconnect(ctx); err != nil {
			log.Fatal(err)
		}
	}
}

// GetCollection returns a collection from the database
func GetCollection(collectionName string) *mongo.Collection {
	return Database.Collection(collectionName)
}
