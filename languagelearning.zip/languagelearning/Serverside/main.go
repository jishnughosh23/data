package main

import (
	"log"
	"os"

	"languagelearning/database"
	"languagelearning/handlers"

	"github.com/gin-gonic/gin"
	"github.com/joho/godotenv"
)

func main() {
	// Load environment variables
	err := godotenv.Load()
	if err != nil {
		log.Printf("Error loading .env file: %v", err)
	}

	// Debug: Print environment variables
	openaiKey := os.Getenv("OPENAI_API_KEY")
	if openaiKey == "" {
		log.Printf("OPENAI_API_KEY is empty")
	} else {
		log.Printf("OPENAI_API_KEY is set (length: %d)", len(openaiKey))
	}

	// Initialize database connection
	database.Init()

	// Create Gin router
	router := gin.Default()

	// Enable CORS
	router.Use(func(c *gin.Context) {
		c.Writer.Header().Set("Access-Control-Allow-Origin", "*")
		c.Writer.Header().Set("Access-Control-Allow-Credentials", "true")
		c.Writer.Header().Set("Access-Control-Allow-Headers", "Content-Type, Content-Length, Accept-Encoding, X-CSRF-Token, Authorization, accept, origin, Cache-Control, X-Requested-With")
		c.Writer.Header().Set("Access-Control-Allow-Methods", "POST, OPTIONS, GET, PUT, DELETE")

		if c.Request.Method == "OPTIONS" {
			c.AbortWithStatus(204)
			return
		}

		c.Next()
	})

	// API routes
	api := router.Group("/api")
	{
		// Public routes (no authentication required)
		api.POST("/register", handlers.Register)
		api.POST("/login", handlers.Login)
		api.GET("/languages", handlers.GetLanguages)
		api.GET("/languages/:id/topics", handlers.GetTopicsByLanguage)

		// Protected routes (authentication required)
		protected := api.Group("/")
		protected.Use(handlers.AuthMiddleware())
		{
			// Session routes
			protected.POST("/sessions", handlers.StartSession)
			protected.PUT("/sessions/:id", handlers.EndSession)
			protected.GET("/sessions/:id/feedback", handlers.GetSessionFeedback)
			protected.GET("/sessions/:id", handlers.GetSession)
			protected.GET("/user/sessions", handlers.GetUserSessions)

			// Progress routes
			protected.GET("/progress", handlers.GetUserProgress)
			protected.PUT("/progress", handlers.UpdateUserProgress)

			// Settings routes
			protected.GET("/settings", handlers.GetUserSettings)
			protected.PUT("/settings", handlers.UpdateUserSettings)
			protected.PUT("/profile", handlers.UpdateUserProfile)
		}
	}

	// WebSocket endpoint
	router.GET("/ws", handlers.HandleWebSocket)

	// Start server
	port := os.Getenv("PORT")
	if port == "" {
		port = "8080"
	}
	router.Run(":" + port)
}
