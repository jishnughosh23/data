package main

import (
	"context"
	"log"
	"time"

	"languagelearning/database"
	"languagelearning/models"

	"go.mongodb.org/mongo-driver/bson/primitive"
)

func main() {
	// Initialize database connection
	database.Init()
	defer database.Close()

	ctx := context.Background()

	// Create sample languages
	languages := []models.Language{
		{
			ID:          primitive.NewObjectID(),
			Name:        "English",
			Code:        "en",
			Description: "English language learning",
			Levels:      []string{"Beginner", "Intermediate", "Advanced"},
			CreatedAt:   time.Now(),
		},
		{
			ID:          primitive.NewObjectID(),
			Name:        "Spanish",
			Code:        "es",
			Description: "Spanish language learning",
			Levels:      []string{"Beginner", "Intermediate", "Advanced"},
			CreatedAt:   time.Now(),
		},
	}

	// Insert languages
	languageCollection := database.Database.Collection("languages")
	for _, lang := range languages {
		_, err := languageCollection.InsertOne(ctx, lang)
		if err != nil {
			log.Printf("Error inserting language %s: %v", lang.Name, err)
			continue
		}
		log.Printf("Inserted language: %s", lang.Name)

		// Create sample topics for each language
		topics := []models.Topic{
			{
				ID:          primitive.NewObjectID(),
				Title:       "Greetings and Introductions",
				Description: "Learn how to greet people and introduce yourself",
				Difficulty:  "Beginner",
				LanguageID:  lang.ID,
				Category:    "Conversation",
				Keywords:    []string{"hello", "greetings", "introductions"},
				Prompts: []string{
					"Introduce yourself and tell us about your hobbies",
					"Practice greeting someone in different situations",
					"Have a conversation about your daily routine",
				},
				CreatedAt: time.Now(),
			},
			{
				ID:          primitive.NewObjectID(),
				Title:       "Travel and Transportation",
				Description: "Learn vocabulary and phrases for traveling",
				Difficulty:  "Intermediate",
				LanguageID:  lang.ID,
				Category:    "Travel",
				Keywords:    []string{"travel", "transportation", "directions"},
				Prompts: []string{
					"Describe your last vacation",
					"Ask for directions to a specific location",
					"Plan a trip with a friend",
				},
				CreatedAt: time.Now(),
			},
		}

		// Insert topics
		topicCollection := database.Database.Collection("topics")
		for _, topic := range topics {
			_, err := topicCollection.InsertOne(ctx, topic)
			if err != nil {
				log.Printf("Error inserting topic %s: %v", topic.Title, err)
				continue
			}
			log.Printf("Inserted topic: %s for language %s", topic.Title, lang.Name)
		}
	}

	log.Println("Database initialization completed!")
}
