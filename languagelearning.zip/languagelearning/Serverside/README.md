# Language Learning Backend

This is the backend server for the language learning application. It provides RESTful APIs and WebSocket endpoints for managing language learning sessions, feedback, and progress tracking.

## Prerequisites

- Go 1.21 or later
- MongoDB Atlas account
- OpenAI API key

## Setup

1. Clone the repository
2. Install dependencies:
   ```bash
   go mod download
   ```

3. Create a `.env` file in the root directory with the following variables:
   ```
   # MongoDB Connection
   MONGODB_URI=mongodb+srv://your-username:your-password@your-cluster.mongodb.net/languagelearning?retryWrites=true&w=majority

   # OpenAI API
   OPENAI_API_KEY=your-openai-api-key

   # Server Configuration
   PORT=8080
   ```

4. Run the server:
   ```bash
   go run main.go
   ```

## API Endpoints

### Languages
- `GET /api/languages` - Get all available languages
- `GET /api/languages/:id/topics` - Get topics for a specific language

### Sessions
- `POST /api/sessions` - Start a new practice session
- `PUT /api/sessions/:id` - End a session with feedback
- `GET /api/sessions/:id/feedback` - Get feedback for a session

### Progress
- `GET /api/progress` - Get user progress
- `PUT /api/progress` - Update user progress

### WebSocket
- `GET /ws` - WebSocket endpoint for real-time feedback

## Database Schema

### Languages
```go
type Language struct {
    ID          primitive.ObjectID `bson:"_id,omitempty" json:"id"`
    Name        string            `bson:"name" json:"name"`
    Code        string            `bson:"code" json:"code"`
    Description string            `bson:"description" json:"description"`
    Levels      []string          `bson:"levels" json:"levels"`
    CreatedAt   time.Time         `bson:"created_at" json:"created_at"`
}
```

### Topics
```go
type Topic struct {
    ID          primitive.ObjectID `bson:"_id,omitempty" json:"id"`
    Title       string            `bson:"title" json:"title"`
    Description string            `bson:"description" json:"description"`
    Difficulty  string            `bson:"difficulty" json:"difficulty"`
    LanguageID  primitive.ObjectID `bson:"language_id" json:"language_id"`
    Category    string            `bson:"category" json:"category"`
    Keywords    []string          `bson:"keywords" json:"keywords"`
    Prompts     []string          `bson:"prompts" json:"prompts"`
    CreatedAt   time.Time         `bson:"created_at" json:"created_at"`
}
```

### Practice Sessions
```go
type PracticeSession struct {
    ID        primitive.ObjectID `bson:"_id,omitempty" json:"id"`
    UserID    primitive.ObjectID `bson:"user_id" json:"user_id"`
    TopicID   primitive.ObjectID `bson:"topic_id" json:"topic_id"`
    StartTime time.Time         `bson:"start_time" json:"start_time"`
    EndTime   time.Time         `bson:"end_time" json:"end_time"`
    Status    string            `bson:"status" json:"status"`
    Feedback  Feedback          `bson:"feedback" json:"feedback"`
    CreatedAt time.Time         `bson:"created_at" json:"created_at"`
    UpdatedAt time.Time         `bson:"updated_at" json:"updated_at"`
}
```

### Feedback
```go
type Feedback struct {
    ID            primitive.ObjectID `bson:"_id,omitempty" json:"id"`
    SessionID     primitive.ObjectID `bson:"session_id" json:"session_id"`
    Transcript    string            `bson:"transcript" json:"transcript"`
    Analysis      string            `bson:"analysis" json:"analysis"`
    Grammar       FeedbackDetail    `bson:"grammar" json:"grammar"`
    Pronunciation FeedbackDetail    `bson:"pronunciation" json:"pronunciation"`
    Fluency       FeedbackDetail    `bson:"fluency" json:"fluency"`
    Timestamp     time.Time         `bson:"timestamp" json:"timestamp"`
}

type FeedbackDetail struct {
    Score       float64  `bson:"score" json:"score"`
    Corrections []string `bson:"corrections,omitempty" json:"corrections,omitempty"`
    Feedback    string   `bson:"feedback,omitempty" json:"feedback,omitempty"`
}
```

### User Progress
```go
type UserProgress struct {
    ID                        primitive.ObjectID `bson:"_id,omitempty" json:"id"`
    UserID                    primitive.ObjectID `bson:"user_id" json:"user_id"`
    LanguageID                primitive.ObjectID `bson:"language_id" json:"language_id"`
    TotalSessions             int                `bson:"total_sessions" json:"total_sessions"`
    AverageGrammarScore       float64            `bson:"average_grammar_score" json:"average_grammar_score"`
    AverageFluencyScore       float64            `bson:"average_fluency_score" json:"average_fluency_score"`
    AveragePronunciationScore float64            `bson:"average_pronunciation_score" json:"average_pronunciation_score"`
    LastPracticedAt           time.Time          `bson:"last_practiced_at" json:"last_practiced_at"`
    CreatedAt                 time.Time          `bson:"created_at" json:"created_at"`
    UpdatedAt                 time.Time          `bson:"updated_at" json:"updated_at"`
}
```

## Development

### Project Structure
```
.
├── main.go              # Main application entry point
├── database/
│   └── database.go      # Database connection and configuration
├── handlers/
│   ├── language.go      # Language-related handlers
│   ├── session.go       # Session-related handlers
│   ├── progress.go      # Progress-related handlers
│   └── websocket.go     # WebSocket handler
├── models/
│   ├── language.go      # Language model
│   ├── topic.go         # Topic model
│   ├── practicesession.go # Practice session model
│   ├── feedback.go      # Feedback model
│   └── userprogress.go  # User progress model
└── README.md            # Project documentation
```

### Running Tests
```bash
go test ./...
```

### Code Style
- Follow Go's standard formatting using `gofmt`
- Use meaningful variable and function names
- Add comments for exported functions and types
- Keep functions small and focused on a single responsibility

### Error Handling
- Use proper error handling throughout the codebase
- Return meaningful error messages
- Log errors appropriately
- Handle edge cases gracefully

### Security
- Use environment variables for sensitive data
- Implement proper input validation
- Use HTTPS in production
- Implement rate limiting for API endpoints
- Validate user input and sanitize data

### Performance
- Use connection pooling for database connections
- Implement caching where appropriate
- Optimize database queries
- Use proper indexing for MongoDB collections 