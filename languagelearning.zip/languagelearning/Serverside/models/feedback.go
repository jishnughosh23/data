package models

import (
	"time"

	"go.mongodb.org/mongo-driver/bson/primitive"
)

type Feedback struct {
	ID            primitive.ObjectID `bson:"_id,omitempty" json:"id"`
	SessionID     primitive.ObjectID `bson:"session_id" json:"session_id"`
	Transcript    string             `bson:"transcript" json:"transcript"`
	Analysis      string             `bson:"analysis" json:"analysis"`
	Grammar       float64            `bson:"grammar" json:"grammar"`
	Pronunciation float64            `bson:"pronunciation" json:"pronunciation"`
	Fluency       float64            `bson:"fluency" json:"fluency"`
	Timestamp     time.Time          `bson:"timestamp" json:"timestamp"`
	Score         float64            `bson:"score" json:"score"`
	Corrections   []string           `bson:"corrections,omitempty" json:"corrections,omitempty"`
	Feedback      string             `bson:"feedback,omitempty" json:"feedback,omitempty"`
}
