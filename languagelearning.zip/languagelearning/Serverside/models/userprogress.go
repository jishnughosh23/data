package models

import (
	"time"

	"go.mongodb.org/mongo-driver/bson/primitive"
)

type UserProgress struct {
	ID                        primitive.ObjectID `bson:"_id,omitempty" json:"id"`
	UserID                    primitive.ObjectID `bson:"user_id" json:"user_id"`
	LanguageID                primitive.ObjectID `bson:"language_id" json:"language_id"`
	TotalSessions             int                `bson:"total_sessions" json:"total_sessions"`
	AverageGrammarScore       float64            `bson:"average_grammar_score" json:"average_grammar_score"`
	AverageFluencyScore       float64            `bson:"average_fluency_score" json:"average_fluency_score"`
	AveragePronunciationScore float64            `bson:"average_pronunciation_score" json:"average_pronunciation_score"`
	LastPracticedAt           time.Time          `bson:"last_practiced_at" json:"last_practiced_at"`
	CreatedAt                 time.Time          `bson:"created_at" json:"created_at"`
	UpdatedAt                 time.Time          `bson:"updated_at" json:"updated_at"`
}
