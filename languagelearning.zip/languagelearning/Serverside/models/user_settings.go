package models

import (
	"time"

	"go.mongodb.org/mongo-driver/bson/primitive"
)

type UserSettings struct {
	ID                 primitive.ObjectID `bson:"_id,omitempty" json:"id"`
	UserID             primitive.ObjectID `bson:"user_id" json:"user_id"`
	PrimaryLanguage    string             `bson:"primary_language" json:"primary_language"`
	LearningLanguages  []string           `bson:"learning_languages" json:"learning_languages"`
	Notifications      Notifications      `bson:"notifications" json:"notifications"`
	AudioSettings      AudioSettings      `bson:"audio_settings" json:"audio_settings"`
	VideoSettings      VideoSettings      `bson:"video_settings" json:"video_settings"`
	Bio                string             `bson:"bio,omitempty" json:"bio,omitempty"`
	CreatedAt          time.Time          `bson:"created_at" json:"created_at"`
	UpdatedAt          time.Time          `bson:"updated_at" json:"updated_at"`
}

type Notifications struct {
	Practice     bool `bson:"practice" json:"practice"`
	Achievements bool `bson:"achievements" json:"achievements"`
	Reminders    bool `bson:"reminders" json:"reminders"`
	Marketing    bool `bson:"marketing" json:"marketing"`
}

type AudioSettings struct {
	Microphone string `bson:"microphone" json:"microphone"`
	Speakers   string `bson:"speakers" json:"speakers"`
	Volume     int    `bson:"volume" json:"volume"`
}

type VideoSettings struct {
	Camera  string `bson:"camera" json:"camera"`
	Quality string `bson:"quality" json:"quality"`
}