package models

import (
	"time"

	"go.mongodb.org/mongo-driver/bson/primitive"
)

type Topic struct {
	ID          primitive.ObjectID `bson:"_id,omitempty" json:"id"`
	Title       string             `bson:"title" json:"title"`
	Description string             `bson:"description" json:"description"`
	Difficulty  string             `bson:"difficulty" json:"difficulty"`
	LanguageID  primitive.ObjectID `bson:"language_id" json:"language_id"`
	Category    string             `bson:"category" json:"category"`
	Keywords    []string           `bson:"keywords" json:"keywords"`
	Prompts     []string           `bson:"prompts" json:"prompts"`
	CreatedAt   time.Time          `bson:"created_at" json:"created_at"`
}
