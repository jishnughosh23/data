package models

import (
	"time"

	"go.mongodb.org/mongo-driver/bson/primitive"
)

type Language struct {
	ID          primitive.ObjectID `bson:"_id,omitempty" json:"id"`
	Name        string             `bson:"name" json:"name"`
	Code        string             `bson:"code" json:"code"`
	Description string             `bson:"description" json:"description"`
	Levels      []string           `bson:"levels" json:"levels"`
	CreatedAt   time.Time          `bson:"created_at" json:"created_at"`
}
