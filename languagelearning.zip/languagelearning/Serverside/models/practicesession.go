package models

import (
	"time"

	"go.mongodb.org/mongo-driver/bson/primitive"
)

type PracticeSession struct {
	ID        primitive.ObjectID `bson:"_id,omitempty" json:"id"`
	UserID    primitive.ObjectID `bson:"user_id" json:"user_id"`
	TopicID   primitive.ObjectID `bson:"topic_id" json:"topic_id"`
	StartTime time.Time          `bson:"start_time" json:"start_time"`
	EndTime   time.Time          `bson:"end_time" json:"end_time"`
	Status    string             `bson:"status" json:"status"`
	Feedback  Feedback           `bson:"feedback" json:"feedback"`
	CreatedAt time.Time          `bson:"created_at" json:"created_at"`
	UpdatedAt time.Time          `bson:"updated_at" json:"updated_at"`
}
