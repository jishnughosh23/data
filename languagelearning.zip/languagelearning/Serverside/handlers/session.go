package handlers

import (
	"context"
	"log"
	"net/http"
	// "os"
	"time"

	"languagelearning/database"
	"languagelearning/models"

	"github.com/gin-gonic/gin"
	"github.com/sashabaranov/go-openai"
	"go.mongodb.org/mongo-driver/bson"
	"go.mongodb.org/mongo-driver/bson/primitive"
)

var openaiClient *openai.Client

func init() {
	apiKey := "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"
	if apiKey == "" {
		log.Fatal("OPENAI_API_KEY environment variable is not set")
	}
	openaiClient = openai.NewClient(apiKey)
}

func StartSession(c *gin.Context) {
	var session models.PracticeSession
	if err := c.ShouldBindJSON(&session); err != nil {
		c.JSON(http.StatusBadRequest, gin.H{"error": err.Error()})
		return
	}

	session.StartTime = time.Now()
	session.Status = "active"

	collection := database.GetCollection("practice_sessions")
	ctx, cancel := context.WithTimeout(context.Background(), 10*time.Second)
	defer cancel()

	result, err := collection.InsertOne(ctx, session)
	if err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{"error": err.Error()})
		return
	}

	session.ID = result.InsertedID.(primitive.ObjectID)
	c.JSON(http.StatusCreated, session)
}

func EndSession(c *gin.Context) {
	sessionID := c.Param("id")
	objectID, err := primitive.ObjectIDFromHex(sessionID)
	if err != nil {
		c.JSON(http.StatusBadRequest, gin.H{"error": "Invalid session ID"})
		return
	}

	var feedback models.Feedback
	if err := c.ShouldBindJSON(&feedback); err != nil {
		c.JSON(http.StatusBadRequest, gin.H{"error": err.Error()})
		return
	}

	// Set the session ID in the feedback if it's not already set
	if feedback.SessionID.IsZero() {
		feedback.SessionID = objectID
	}

	// Set timestamp if not provided
	if feedback.Timestamp.IsZero() {
		feedback.Timestamp = time.Now()
	}

	collection := database.GetCollection("practice_sessions")
	ctx, cancel := context.WithTimeout(context.Background(), 10*time.Second)
	defer cancel()

	update := bson.M{
		"$set": bson.M{
			"end_time": time.Now(),
			"status":   "completed",
			"feedback": feedback,
		},
	}

	_, err = collection.UpdateOne(ctx, bson.M{"_id": objectID}, update)
	if err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{"error": err.Error()})
		return
	}

	c.JSON(http.StatusOK, gin.H{"message": "Session ended successfully"})
}

func GetSessionFeedback(c *gin.Context) {
	sessionID := c.Param("id")
	objectID, err := primitive.ObjectIDFromHex(sessionID)
	if err != nil {
		c.JSON(http.StatusBadRequest, gin.H{"error": "Invalid session ID"})
		return
	}

	collection := database.GetCollection("practice_sessions")
	ctx, cancel := context.WithTimeout(context.Background(), 10*time.Second)
	defer cancel()

	var session models.PracticeSession
	err = collection.FindOne(ctx, bson.M{"_id": objectID}).Decode(&session)
	if err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{"error": err.Error()})
		return
	}

	c.JSON(http.StatusOK, session.Feedback)
}

func GetSession(c *gin.Context) {
	sessionID := c.Param("id")
	objectID, err := primitive.ObjectIDFromHex(sessionID)
	if err != nil {
		c.JSON(http.StatusBadRequest, gin.H{"error": "Invalid session ID"})
		return
	}

	collection := database.GetCollection("practice_sessions")
	ctx, cancel := context.WithTimeout(context.Background(), 10*time.Second)
	defer cancel()

	var session models.PracticeSession
	err = collection.FindOne(ctx, bson.M{"_id": objectID}).Decode(&session)
	if err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{"error": err.Error()})
		return
	}

	c.JSON(http.StatusOK, session)
}

func ProcessAudioFeedback(audioData []byte) (*models.Feedback, error) {
	// Transcribe audio using Whisper
	req := openai.AudioRequest{
		Model:    openai.Whisper1,
		FilePath: "temp_audio.wav",
		Format:   openai.AudioResponseFormatText,
	}

	transcript, err := openaiClient.CreateTranscription(context.Background(), req)
	if err != nil {
		return nil, err
	}

	// Generate feedback using ChatGPT
	chatReq := openai.ChatCompletionRequest{
		Model: openai.GPT4,
		Messages: []openai.ChatCompletionMessage{
			{
				Role:    openai.ChatMessageRoleSystem,
				Content: "You are a language learning assistant. Analyze the following transcript and provide feedback on grammar, pronunciation, and fluency.",
			},
			{
				Role:    openai.ChatMessageRoleUser,
				Content: transcript.Text,
			},
		},
	}

	chatResp, err := openaiClient.CreateChatCompletion(context.Background(), chatReq)
	if err != nil {
		return nil, err
	}

	feedback := &models.Feedback{
		Transcript: transcript.Text,
		Analysis:   chatResp.Choices[0].Message.Content,
		Timestamp:  time.Now(),
	}

	return feedback, nil
}
