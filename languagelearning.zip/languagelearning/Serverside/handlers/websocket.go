package handlers

import (
	"encoding/json"
	"log"
	"net/http"

	"github.com/gin-gonic/gin"
	"github.com/gorilla/websocket"
)

var upgrader = websocket.Upgrader{
	ReadBufferSize:  1024,
	WriteBufferSize: 1024,
	CheckOrigin: func(r *http.Request) bool {
		return true // Allow all origins for development
	},
}

type WebSocketMessage struct {
	Type    string          `json:"type"`
	Payload json.RawMessage `json:"payload"`
}

func HandleWebSocket(c *gin.Context) {
	conn, err := upgrader.Upgrade(c.Writer, c.Request, nil)
	if err != nil {
		log.Printf("Failed to upgrade connection: %v", err)
		return
	}
	defer conn.Close()

	for {
		var msg WebSocketMessage
		err := conn.ReadJSON(&msg)
		if err != nil {
			log.Printf("Error reading message: %v", err)
			break
		}

		switch msg.Type {
		case "audio":
			var audioData []byte
			if err := json.Unmarshal(msg.Payload, &audioData); err != nil {
				log.Printf("Error unmarshaling audio data: %v", err)
				continue
			}

			feedback, err := ProcessAudioFeedback(audioData)
			if err != nil {
				log.Printf("Error processing audio: %v", err)
				continue
			}

			response := WebSocketMessage{
				Type: "feedback",
				Payload: json.RawMessage(`{
					"transcript": "` + feedback.Transcript + `",
					"analysis": "` + feedback.Analysis + `"
				}`),
			}

			if err := conn.WriteJSON(response); err != nil {
				log.Printf("Error sending feedback: %v", err)
				break
			}
		}
	}
}
