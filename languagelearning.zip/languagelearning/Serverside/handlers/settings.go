package handlers

import (
	"context"
	"net/http"
	"time"

	"languagelearning/database"
	"languagelearning/models"

	"github.com/gin-gonic/gin"
	"go.mongodb.org/mongo-driver/bson"
	"go.mongodb.org/mongo-driver/bson/primitive"
	"go.mongodb.org/mongo-driver/mongo"
	"go.mongodb.org/mongo-driver/mongo/options"
)

// GetUserSettings retrieves the settings for the authenticated user
func GetUserSettings(c *gin.Context) {
	// Get user ID from token
	userID, exists := c.Get("userID")
	if !exists {
		c.JSON(http.StatusUnauthorized, gin.H{"error": "User not authenticated"})
		return
	}

	// Convert userID to ObjectID
	userObjectID, err := primitive.ObjectIDFromHex(userID.(string))
	if err != nil {
		c.JSON(http.StatusBadRequest, gin.H{"error": "Invalid user ID"})
		return
	}

	// Create context with timeout
	ctx, cancel := context.WithTimeout(context.Background(), 10*time.Second)
	defer cancel()

	// Get settings collection
	settingsCollection := database.GetCollection("user_settings")

	// Find settings for this user
	var settings models.UserSettings
	err = settingsCollection.FindOne(ctx, bson.M{"user_id": userObjectID}).Decode(&settings)

	if err != nil {
		if err == mongo.ErrNoDocuments {
			// If no settings found, return default settings
			defaultSettings := models.UserSettings{
				UserID:            userObjectID,
				PrimaryLanguage:   "english",
				LearningLanguages: []string{},
				Notifications: models.Notifications{
					Practice:     true,
					Achievements: true,
					Reminders:    true,
					Marketing:    false,
				},
				AudioSettings: models.AudioSettings{
					Microphone: "default",
					Speakers:   "default",
					Volume:     80,
				},
				VideoSettings: models.VideoSettings{
					Camera:  "default",
					Quality: "hd",
				},
				CreatedAt: time.Now(),
				UpdatedAt: time.Now(),
			}
			c.JSON(http.StatusOK, defaultSettings)
			return
		}
		c.JSON(http.StatusInternalServerError, gin.H{"error": "Failed to retrieve settings"})
		return
	}

	c.JSON(http.StatusOK, settings)
}

// UpdateUserSettings updates the settings for the authenticated user
func UpdateUserSettings(c *gin.Context) {
	// Get user ID from token
	userID, exists := c.Get("userID")
	if !exists {
		c.JSON(http.StatusUnauthorized, gin.H{"error": "User not authenticated"})
		return
	}

	// Convert userID to ObjectID
	userObjectID, err := primitive.ObjectIDFromHex(userID.(string))
	if err != nil {
		c.JSON(http.StatusBadRequest, gin.H{"error": "Invalid user ID"})
		return
	}

	// Parse request body
	var settings models.UserSettings
	if err := c.ShouldBindJSON(&settings); err != nil {
		c.JSON(http.StatusBadRequest, gin.H{"error": err.Error()})
		return
	}

	// Ensure user ID is set correctly
	settings.UserID = userObjectID
	settings.UpdatedAt = time.Now()

	// Create context with timeout
	ctx, cancel := context.WithTimeout(context.Background(), 10*time.Second)
	defer cancel()

	// Get settings collection
	settingsCollection := database.GetCollection("user_settings")

	// Check if settings already exist for this user
	var existingSettings models.UserSettings
	err = settingsCollection.FindOne(ctx, bson.M{"user_id": userObjectID}).Decode(&existingSettings)

	if err != nil {
		if err == mongo.ErrNoDocuments {
			// If no settings found, create new settings
			settings.CreatedAt = time.Now()
			result, err := settingsCollection.InsertOne(ctx, settings)
			if err != nil {
				c.JSON(http.StatusInternalServerError, gin.H{"error": "Failed to create settings"})
				return
			}
			settings.ID = result.InsertedID.(primitive.ObjectID)
		} else {
			c.JSON(http.StatusInternalServerError, gin.H{"error": "Failed to check existing settings"})
			return
		}
	} else {
		// If settings exist, update them
		settings.ID = existingSettings.ID
		settings.CreatedAt = existingSettings.CreatedAt

		// Update settings
		_, err = settingsCollection.ReplaceOne(
			ctx,
			bson.M{"_id": existingSettings.ID},
			settings,
		)

		if err != nil {
			c.JSON(http.StatusInternalServerError, gin.H{"error": "Failed to update settings"})
			return
		}
	}

	c.JSON(http.StatusOK, settings)
}

// UpdateUserProfile updates the user profile information
func UpdateUserProfile(c *gin.Context) {
	// Get user ID from token
	userID, exists := c.Get("userID")
	if !exists {
		c.JSON(http.StatusUnauthorized, gin.H{"error": "User not authenticated"})
		return
	}

	// Convert userID to ObjectID
	userObjectID, err := primitive.ObjectIDFromHex(userID.(string))
	if err != nil {
		c.JSON(http.StatusBadRequest, gin.H{"error": "Invalid user ID"})
		return
	}

	// Parse request body
	type ProfileUpdate struct {
		Username  string `json:"username"`
		Email     string `json:"email"`
		Bio       string `json:"bio"`
		AvatarURL string `json:"avatarUrl"`
	}

	var profileUpdate ProfileUpdate
	if err := c.ShouldBindJSON(&profileUpdate); err != nil {
		c.JSON(http.StatusBadRequest, gin.H{"error": err.Error()})
		return
	}

	// Create context with timeout
	ctx, cancel := context.WithTimeout(context.Background(), 10*time.Second)
	defer cancel()

	// Get users collection
	usersCollection := database.GetCollection("users")

	// Update user profile
	update := bson.M{
		"$set": bson.M{
			"username":   profileUpdate.Username,
			"email":      profileUpdate.Email,
			"avatarUrl":  profileUpdate.AvatarURL,
			"updated_at": time.Now(),
		},
	}

	// Apply update
	_, err = usersCollection.UpdateOne(
		ctx,
		bson.M{"_id": userObjectID},
		update,
		options.Update().SetUpsert(false),
	)

	if err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{"error": "Failed to update profile"})
		return
	}

	// Also update bio in settings if it exists
	settingsCollection := database.GetCollection("user_settings")
	settingsUpdate := bson.M{
		"$set": bson.M{
			"bio":        profileUpdate.Bio,
			"updated_at": time.Now(),
		},
	}

	_, _ = settingsCollection.UpdateOne(
		ctx,
		bson.M{"user_id": userObjectID},
		settingsUpdate,
		options.Update().SetUpsert(true),
	)

	c.JSON(http.StatusOK, gin.H{"message": "Profile updated successfully"})
}