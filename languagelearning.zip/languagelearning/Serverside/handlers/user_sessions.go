package handlers

import (
	"context"
	"net/http"
	"time"

	"languagelearning/database"
	"languagelearning/models"

	"github.com/gin-gonic/gin"
	"go.mongodb.org/mongo-driver/bson"
	"go.mongodb.org/mongo-driver/mongo/options"
)

// GetUserSessions retrieves all practice sessions for the authenticated user
func GetUserSessions(c *gin.Context) {
	// Get user ID from token
	userID, exists := c.Get("userID")
	if !exists {
		c.JSON(http.StatusUnauthorized, gin.H{"error": "User not authenticated"})
		return
	}

	// Create context with timeout
	ctx, cancel := context.WithTimeout(context.Background(), 10*time.Second)
	defer cancel()

	// Get sessions collection
	sessionsCollection := database.GetCollection("practice_sessions")

	// Define options for sorting by start time in descending order
	opts := options.Find().SetSort(bson.D{{"startTime", -1}})

	// Find all sessions for this user
	cursor, err := sessionsCollection.Find(ctx, bson.M{"userId": userID}, opts)
	if err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{"error": "Failed to retrieve sessions"})
		return
	}
	defer cursor.Close(ctx)

	// Decode sessions
	var sessions []models.PracticeSession
	if err := cursor.All(ctx, &sessions); err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{"error": "Failed to decode sessions"})
		return
	}

	// Return sessions
	c.JSON(http.StatusOK, sessions)
}